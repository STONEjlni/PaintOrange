//app.js
var qcloud = require('./vendor/wafer2-client-sdk/index');
var config = require('./config');
var common = require("pages/common/common.js")
var common_js = require("utils/common.js")

var Moment = require("/utils/moment.js");
var DATE_LIST = [];
var DATE_YEAR = new Date().getFullYear();
var DATE_MONTH = new Date().getMonth() + 1;
var DATE_DAY = new Date().getDate();

var app = getApp();
App({
  btn:'',
  globalData:{
    name: "",
    phone: "",
    source: "",
    isPub: false,
    sex: "男",
    isSubmit: false,
    peopleNumber: "",
    checkSession: {
      checkInSession: "白天场",
      checkOutSession: "白天场"
    },
    checkInDate: Moment(new Date()).add(0,'day').format('YYYY-MM-DD'),
    checkOutDate: Moment(new Date()).add(0,'day').format('YYYY-MM-DD'),
    banDate:[],
    limitDate :[],
    hallNo:'X01',
    hall: [
      {name: '小和山一号馆', No: 'X01', location: '留和路135号UN公社4幢311室', phone: '15868863709', qrcode: 'qrcode1', id: 1, GnfItems: [
          {id: 1, icon: "bbq.png", title: "烧烤"},  { id: 2,icon: "zhuoyou.png", title: "桌游室" },{ id: 3,icon: "yinyin.png", title: "影音室"},{ id: 4,icon: "majiangg.png",title: "麻将室"},
          {
            id: 5,
            icon: "kitchen.png",
            title: "厨房"
          },
        ]},
      {
        name: '小和山二号馆', No: 'X02', location: '留和路135号UN公社7幢101室', phone: '15868863709', qrcode: 'qrcode1', id: 2, GnfItems: [
          {
            id: 1,
            icon: "KTV.png",
            title: "KTV"
          },
          {
            id: 2,
            icon: "zhuoyou.png",
            title: "桌游室"
          },
          {
            id: 3,
            icon: "yinyin.png",
            title: "影音室"
          },
          {
            id: 4,
            icon: "majiangg.png",
            title: "麻将室"
          },
          {
            id: 5,
            icon: "kitchen.png",
            title: "厨房"
          },
        ] }, 
      { name: '紫金港一号馆', No: 'Z01', location: '申花路359号申瑞国际二期金座1幢1003', phone: '17326088171', qrcode: 'qrcode2', id: 3,GnfItems: [
        {
          id: 1,
          icon: "KTV.png",
          title: "KTV"
        },
        {
          id: 2,
          icon: "zhuoyou.png",
          title: "桌游室"
        },
        {
          id: 3,
          icon: "yinyin.png",
          title: "影音室"
        },
        {
          id: 4,
          icon: "majiangg.png",
          title: "麻将室"
        },
        {
          id: 5,
          icon: "kitchen.png",
          title: "厨房"
        },
      ] }],
    price: [
      { hallNo: "Z01", week: 1, session: "白天场", price: 788 }, 
      { hallNo: "Z01", week: 1, session: "夜晚场", price: 888 },
      { hallNo: "Z01", week: 1, session: "凌晨场", price: 688 },
      { hallNo: "Z01", week: 2, session: "白天场", price: 788 },
      { hallNo: "Z01", week: 2, session: "夜晚场", price: 888 },
      { hallNo: "Z01", week: 2, session: "凌晨场", price: 688 },
      { hallNo: "Z01", week: 3, session: "白天场", price: 788 },
      { hallNo: "Z01", week: 3, session: "夜晚场", price: 888 },
      { hallNo: "Z01", week: 3, session: "凌晨场", price: 688 },
      { hallNo: "Z01", week: 4, session: "白天场", price: 988 },
      { hallNo: "Z01", week: 4, session: "夜晚场", price: 1088 },
      { hallNo: "Z01", week: 4, session: "凌晨场", price: 888 },
      { hallNo: "Z01", week: 5, session: "白天场", price: 1188 },
      { hallNo: "Z01", week: 5, session: "夜晚场", price: 1388 },
      { hallNo: "Z01", week: 5, session: "凌晨场", price: 1088 },
      { hallNo: "Z01", week: 6, session: "白天场", price: 1188 },
      { hallNo: "Z01", week: 6, session: "夜晚场", price: 1388 },
      { hallNo: "Z01", week: 6, session: "凌晨场", price: 1088 },
      { hallNo: "Z01", week: 7, session: "白天场", price: 1188 },
      { hallNo: "Z01", week: 7, session: "夜晚场", price: 1388 },
      { hallNo: "Z01", week: 7, session: "凌晨场", price: 1088 },

      { hallNo: "X01", week: 1, session: "白天场", price: 788 },
      { hallNo: "X01", week: 1, session: "夜晚场", price: 888 },
      { hallNo: "X01", week: 1, session: "凌晨场", price: 588 },
      { hallNo: "X01", week: 2, session: "白天场", price: 788 },
      { hallNo: "X01", week: 2, session: "夜晚场", price: 888 },
      { hallNo: "X01", week: 2, session: "凌晨场", price: 588 },
      { hallNo: "X01", week: 3, session: "白天场", price: 788 },
      { hallNo: "X01", week: 3, session: "夜晚场", price: 888 },
      { hallNo: "X01", week: 3, session: "凌晨场", price: 588 },
      { hallNo: "X01", week: 4, session: "白天场", price: 788 },
      { hallNo: "X01", week: 4, session: "夜晚场", price: 888 },
      { hallNo: "X01", week: 4, session: "凌晨场", price: 588 },
      { hallNo: "X01", week: 5, session: "白天场", price: 1088 },
      { hallNo: "X01", week: 5, session: "夜晚场", price: 1188 },
      { hallNo: "X01", week: 5, session: "凌晨场", price: 888 },
      { hallNo: "X01", week: 6, session: "白天场", price: 1088 },
      { hallNo: "X01", week: 6, session: "夜晚场", price: 1188 },
      { hallNo: "X01", week: 6, session: "凌晨场", price: 888 },
      { hallNo: "X01", week: 7, session: "白天场", price: 1088 },
      { hallNo: "X01", week: 7, session: "夜晚场", price: 1188 },
      { hallNo: "X01", week: 7, session: "凌晨场", price: 888 },

      { hallNo: "X02", week: 1, session: "白天场", price: 788 },
      { hallNo: "X02", week: 1, session: "夜晚场", price: 888 },
      { hallNo: "X02", week: 1, session: "凌晨场", price: 588 },
      { hallNo: "X02", week: 2, session: "白天场", price: 788 },
      { hallNo: "X02", week: 2, session: "夜晚场", price: 888 },
      { hallNo: "X02", week: 2, session: "凌晨场", price: 588 },
      { hallNo: "X02", week: 3, session: "白天场", price: 788 },
      { hallNo: "X02", week: 3, session: "夜晚场", price: 888 },
      { hallNo: "X02", week: 3, session: "凌晨场", price: 588 },
      { hallNo: "X02", week: 4, session: "白天场", price: 788 },
      { hallNo: "X02", week: 4, session: "夜晚场", price: 888 },
      { hallNo: "X02", week: 4, session: "凌晨场", price: 588 },
      { hallNo: "X02", week: 5, session: "白天场", price: 1088 },
      { hallNo: "X02", week: 5, session: "夜晚场", price: 1188 },
      { hallNo: "X02", week: 5, session: "凌晨场", price: 888 },
      { hallNo: "X02", week: 6, session: "白天场", price: 1088 },
      { hallNo: "X02", week: 6, session: "夜晚场", price: 1188 },
      { hallNo: "X02", week: 6, session: "凌晨场", price: 888 },
      { hallNo: "X02", week: 7, session: "白天场", price: 1088 },
      { hallNo: "X02", week: 7, session: "夜晚场", price: 1188 },
      { hallNo: "X02", week: 7, session: "凌晨场", price: 888 },



    ]
  },
    onLaunch: function () {
        qcloud.setLoginUrl(config.service.loginUrl);
      wx.login({
        success: function (res) {
          if (res.code) {
            //发起网络请求  
            console.log(res.code)
           
            
          } else {
            console.log('获取用户登录态失败！' + res.errMsg)
          }
        }
      }); 
      //this.getBanDate();
    },


    func:{
      getPrice: common_js.getPrice
    }
    
})

