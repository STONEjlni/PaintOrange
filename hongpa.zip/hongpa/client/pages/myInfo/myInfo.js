// pages/myInfo/myInfo.js
let app = getApp();
Page({
  data: {
    host:'https://www.paintorange.com',
    isSubmit: app.globalData.isSubmit,
    warn: "",
    name: app.globalData.name,
    phone: app.globalData.phone,
    source: app.globalData.source,
    isPub: app.globalData.isPub,
    sex: app.globalData.sex
  },
  formSubmit: function (e) {
    var that = this;
    //console.log('form发生了submit事件，携带数据为：', e.detail.value);
    let { name, phone, sex } = e.detail.value;
    var phonetel = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (!phone || !name ) {
      this.setData({
        warn: "手机号或姓名为空！",
      })
      this.showModel2();
      return;
    }
    else{
      var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
      if (!myreg.test(phone)) {
        wx.showToast({
          title: '手机号有误！',
          icon: '../../images/err.png',
          image: '../../images/err.png',
          duration: 1500
        })
        return;

      }
      else{
        wx.request({
          url: 'https://www.paintorange.com/userinfo.php',//写自己的服务器
          header: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          method: "POST",
          data: {
            username: name,
            phonenum: phone,
          },
          success: function (e) {
            console.log(e.data);
            if (e.data == 1 || e.data == 4) {//用户名与号码均是新的
              that.showModel1();
              that.setData({
                warn: "",
                isSubmit: true,
                name,
                phone,
                sex,
              });
              that.changeDate();
            }
            else if (e.data == 2) {//号码已经被注册
              that.showModel3();
            }
            else if (e.data == 3) {
              that.showModel4();
            }
            else{
              that.showModel5();
            }


          },
          fail: function () {
            console.log("fail")
          }

        })



      }
    }
    
    

    
  },



  formReset: function () {
    //console.log('form发生了reset事件')
  },

 changeDate: function(){
   var name = this.data.name
   app.globalData.name = name;
   var phone = this.data.phone;
   app.globalData.phone = phone;
   var sex = this.data.sex;
   app.globalData.sex = sex;
   var source = this.data.source;
   app.globalData.source = source;
   var isPub = this.isPub;
   app.globalData.isPub = isPub;
   var isSubmit = this.data.isSubmit;
   app.globalData.isSubmit = isSubmit;
 },

  showModel1: function () {
    　　wx.showModal({
         title: '提示',
         content: '当你下单后，我们的工作人员将会尝试联系你确保订单有效，所以请确保您留的联系方式有效',
      　　success: function (res) {
            if (res.confirm) {
          　　//console.log('用户点击确定')
              wx.navigateBack({
                delta: 1
              })
              //console.log(app.globalData.isSubmit)
        　　}
      　　}
    　　})
  　　},

  　　showModel2: function(){
    　　wx.showModal({
      　　title: '警告⚠️',
         content: '手机号或姓名为空！',
      　　showCancel: true,
      　　confirmText: '确认',
      　　confirmColor: '#FF0000',
      　　cancelText: '取消',
      　　cancelColor: '#999999',
      　　success: function (res) {
        　　if (res.confirm) {
          　　//console.log('用户点击确定');
        　　} else {
          　　//console.log('用户点击取消');
        　　}
      　　},
      　　fail: function () {
        　　//console.log('接口调用失败');
      　　},
      　　complete: function () {
        　　//console.log('接口调用结束')
      　　}
    　　})
  　　},

  showModel3: function () {
    wx.showModal({
      title: '对不起',
      content: '该手机号码已经被人注册！',
      showCancel: true,
      confirmText: '确认',
      confirmColor: '#FF0000',
      cancelText: '取消',
      cancelColor: '#999999',
      success: function (res) {
        if (res.confirm) {
          //console.log('用户点击确定');
        } else {
          //console.log('用户点击取消');
        }
      },
      fail: function () {
        //console.log('接口调用失败');
      },
      complete: function () {
        //console.log('接口调用结束')
      }
    })
  },

  showModel4: function () {
    wx.showModal({
      title: '对不起',
      content: '该用户之前预留与此不符',
      showCancel: true,
      confirmText: '确认',
      confirmColor: '#FF0000',
      cancelText: '取消',
      cancelColor: '#999999',
      success: function (res) {
        if (res.confirm) {
          //console.log('用户点击确定');
        } else {
          //console.log('用户点击取消');
        }
      },
      fail: function () {
        //console.log('接口调用失败');
      },
      complete: function () {
        //console.log('接口调用结束')
      }
    })
  },

  showModel5: function () {
    wx.showModal({
      title: '对不起',
      content: '姓名与电话不匹配',
      showCancel: true,
      confirmText: '确认',
      confirmColor: '#FF0000',
      cancelText: '取消',
      cancelColor: '#999999',
      success: function (res) {
        if (res.confirm) {
          //console.log('用户点击确定');
        } else {
          //console.log('用户点击取消');
        }
      },
      fail: function () {
        //console.log('接口调用失败');
      },
      complete: function () {
        //console.log('接口调用结束')
      }
    })
  },

  onLoad: function (options) {
  },
  onShow: function () {
    this.setData({
      name: app.globalData.name,
      phone: app.globalData.phone,
      source: app.globalData.source,
      isPub: app.globalData.isPub,
      sex: app.globalData.sex,
      isSubmit: app.globalData.isSubmit
    })
    //console.log(this.data.isSubmit)
  },
  

})

