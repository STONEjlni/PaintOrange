
// pages/order/order.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: "https://www.paintorange.com/",
    hallName:"",
    hall: app.globalData.hall,
    location:"",
    checkSession:"",
    checkInDate:"",
    checkOutDate:"",
    session:["凌晨场","白天场","夜晚场"],
    checkDateSession:[],
    buySession : [],
    ifcut:false,
    cut:0,
    hallPrice:0
  },


  addToOrder: function () {
    //监听按钮
    var that = this;
    var hallNo1, cusName1, cusTel1, InDate1, InSesion1, Outdate1, OutSession1, peopleNum1;
    wx.request({
      url: 'https://www.paintorange.com/test.php',//写自己的服务器
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      data: {
        hallNo1: app.globalData.hallNo,
        cusName1: app.globalData.name,
        cusTel1: app.globalData.phone,
        InDate1: app.globalData.checkInDate,
        InSesion1: app.globalData.checkSession.checkInSession,
        Outdate1: app.globalData.checkOutDate,
        OutSession1: app.globalData.checkSession.checkOutSession,
        peopleNum1: app.globalData.peopleNumber,
        price1:that.data.hallPrice,
        cut1:that.data.cut
      },
      success: function () {
        console.log("success")
        that.showModel2();
      },
      fail: function () {
        console.log("fail")
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      checkInDate : app.globalData.checkInDate,
      checkOutDate: app.globalData.checkOutDate,
      checkSession: app.globalData.checkSession,
    })
    var that = this;
    var tempName = ''
    var tempLocation = ''
    for (var i = 0; i < app.globalData.hall.length; i++) {
      if (app.globalData.hall[i].No == app.globalData.hallNo) {
        tempLocation = app.globalData.hall[i].location
        tempName = app.globalData.hall[i].name
      }
    }
    that.setData({
      location: tempLocation,
      hallName: tempName
    })

    var startTime = new Date(that.data.checkInDate)
    var tempTime = new Date(that.data.checkInDate)
    var endTime = new Date(that.data.checkOutDate)
    var tempBuySession = []
    if ((endTime.getTime() - startTime.getTime()) == 0){
      for (var i = that.data.session.indexOf(that.data.checkSession.checkInSession); i <= that.data.session.indexOf(that.data.checkSession.checkOutSession);i++){
        var x ={}
        x.checkDate = that.data.checkInDate;
        x.checkSession = that.data.session[i];
        x.price = 0
        tempBuySession.push(x)
      }
    }
    while ((endTime.getTime() - tempTime.getTime()) >= 0) {
      if (startTime.getTime() != tempTime.getTime() && endTime.getTime() != tempTime.getTime()){
        for(var i=0;i<that.data.session.length;i++){
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = that.data.session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      else if (startTime.getTime() != tempTime.getTime() && endTime.getTime() == tempTime.getTime()){
        for (var i = 0; i < that.data.session.indexOf(that.data.checkSession.checkOutSession)+1; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = that.data.session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      else if (startTime.getTime() == tempTime.getTime() && endTime.getTime() != tempTime.getTime()){
        for (var i = that.data.session.indexOf(that.data.checkSession.checkInSession); i < that.data.session.length; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = that.data.session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      tempTime.setDate(tempTime.getDate() + 1);
    }

    for (var i = 0; i < tempBuySession.length;i++){
      for(var j=0;j<app.globalData.price.length;j++){
        var tt = new Date(tempBuySession[i].checkDate);
        if (app.globalData.hallNo == app.globalData.price[j].hallNo && 
          (tt.getDay() == app.globalData.price[j].week || tt.getDay() == app.globalData.price[j].week-7) && 
          tempBuySession[i].checkSession == app.globalData.price[j].session){
          tempBuySession[i].price = app.globalData.price[j].price;
          }
      }
    }

    
    that.setData({
      buySession: tempBuySession
    })
    var ifcut = false;
    var cut = 0;
    console.log(that.data.buySession)
    if(that.data.buySession.length>=2){
      var ifcut = true;
      if (app.globalData.hallNo == 'X01' || app.globalData.hallNo == 'X02'){
        if (that.data.buySession.length >= 3) { cut = 500 }
        else { cut = 200 }
      }
      else if (app.globalData.hallNo == 'Z01'){
        if (that.data.buySession.length >= 3) { cut = 300 }
        else { cut = 200 }
      }
    }
    that.setData({
      ifcut: ifcut,
      cut:cut
    })

    var pp=0;
    for(var i=0;i<that.data.buySession.length;i++){
      pp += that.data.buySession[i].price;
    }
    //pp -= that.data.cut;
    that.setData({
      hallPrice:pp
    })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  showModel2: function () {
    wx.showModal({
      title: '预定成功',
      content: '我们的工作人员将会在第一时间联系你，请保持手机畅通',
      showCancel: true,
      confirmText: '确认',
      confirmColor: '#FF0000',
      cancelText: '取消',
      cancelColor: '#999999',
      success: function (res) {
        if (res.confirm) {
          //console.log('用户点击确定');
          setTimeout(function () {//跳转
            wx.switchTab({
              url: '/pages/bill/bill',
            })
          }, 80)
        } else {
          //console.log('用户点击取消');
        }
      },
      fail: function () {
        //console.log('接口调用失败');
      },
      complete: function () {
        //console.log('接口调用结束')
      }
    })
  },
})