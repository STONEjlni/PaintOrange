var app = getApp()
Page({
  data: {
    host:"https://www.paintorange.com",
    hasUserInfo: false,
    showView: true,
    list: [
      {
        id: 'myInfo',
        name: '完善我的个人信息',
        click: 'myInfo',
      }
    ]
  },
  getUserInfo: function () {
    var that = this
    if (app.globalData.hasLogin === false) {
      wx.login({
        success: _getUserInfo
      })
    } else {
      _getUserInfo()
    }
    function _getUserInfo() {
      console.log("dd")
      wx.getUserInfo({
        success: function (res) {
          console.log("mm")
          var name = res.userInfo.nickName;
          //app.globalData.name = name;
          //console.log(app.globalData.name);
          that.setData({
            hasUserInfo: true,
            userInfo: res.userInfo,
            showView: (!that.data.showView)
          })
        },
        fail:function(e){
          console.log(e)

        }
      })
    }; 
  },

  kindToggle: function (e) {
    var id = e.currentTarget.id, list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id == id) {
        list[i].open = !list[i].open
      } else {
        list[i].open = false
      }
    }
  },

  kindToggle: function (e) {
    var id = e.currentTarget.id, list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id == id) {
        list[i].open = !list[i].open
      } else {
        list[i].open = false
      }
    }
    this.setData({
      list: list
    });
  },

  myInfo: function (e) {
    wx.navigateTo({
      url: '../myInfo/myInfo'
    })
  }
})
