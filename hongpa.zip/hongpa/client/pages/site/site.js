

Page({
  data: {
    schoolInput: "",
    schoolDatabase: [],
    schoolCandidates: [],
    suggestSearchArray: [],
    isSearch: !1,
    locationAddress: "定位中...",
    location: {},
    searchHistory: [],
    showCityList: !1,
    cityList: [
      {
        province: "杭州市",
        city: "小和山"
      }, 
      {
        province: "杭州市",
        city: "朝晖"
      },
      {
        province: "杭州市",
        city: "上城区"
      },
      {
        province: "杭州市",
        city: "湖滨"
      },
      {
        province: "杭州市",
        city: "孩儿巷"
      },
    ],
    currentCityData:{
      province: "杭州市",
      city: "小和山"
    }
  },
  onLoad: function () {
  },
  onShow: function () {
  },
  onUnload: function () {
  },
  onShareAppMessage: function () { },
  onSwitchPosition: function () {
    this.setData({
      showCityList: !0
    });
  },
  onCityItemClick: function (a) {
    var e = this, 
    s = parseInt(a.currentTarget.id);
    this.setData({
      showCityList: !1,
     currentCityData : this.data.cityList[s],
      isSearch: !1,
      schoolCandidates: []
    }, e.requestSchoolListData);
  },
  toSetting: function () {
    (0, a.default)({
      id: "space_box_dialog",
      title: "获取位置",
      content: "无法获取位置，即将跳到设置页授权定位权限",
      confirmButtonOpenType: "openSetting",
      confirmButtonText: "去设置"
    });
  },
  

  onMashClick: function () {
    this.setData({
      showCityList: !1
    });
  }
});