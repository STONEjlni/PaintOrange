//获取应用实例
var app = getApp()
Page({
  data: {
    host: "http://118.24.48.89",    
    imageWidth: wx.getSystemInfoSync().windowWidth,
    totalIncome: 0.0,
    runningMoney: 0.0,
    publicWelfareMoney: 0.0,
    orderNum: 123456789,
    appointmentNum: 5,
    appointmentTime: '2017年2月16日  11:42',
    orderTime: '2017年1月16日  11:42',
    hasData: true,
    navTab: ["待处理", "我的订单"],
    moneyInfo: [, , , , , , ,],
    nickName: '漆橙轰趴馆',
    phoneNum: '18202801506',
    currentNavtab: 1,
    statusText: ['待接待未付款'],
    startPoint: [0, 0],
    billNewOrder:[],
    billToUse:[],
    billUsing:[],
    billFinish:[],
    billRefund:[],
    tempPrice : 0

  },

  catchtouchstart: function (e) {
    var that = this;
    that.setData({
      startPoint: [e.touches[0].clientX, e.touches[0].clientY]
    })
  },

  catchtouchend: function (e) {
    var that = this;
    var currentNum = parseInt(this.data.currentNavtab);

    // that.endX = e.changedTouches[0].clientX;
    // that.endY = e.changedTouches[0].clientY;

    // if(that.endX  - that.startX > 10 && currentNum > 0){
    //   currentNum -= 1;
    // }

    // if(that.endX - that.startX < -10 && currentNum< this.data.navTab.length -1){
    //   currentNum=currentNum + 1;
    // }

    var endPoint = [e.changedTouches[0].clientX, e.changedTouches[0].clientY];
    var startPoint = that.data.startPoint
    if (endPoint[0] <= startPoint[0]) {
      if (Math.abs(endPoint[0] - startPoint[0]) >= Math.abs(endPoint[1] - startPoint[1]) && currentNum < this.data.navTab.length - 1) {
        currentNum = currentNum + 1;
      }
    } else {
      if (Math.abs(endPoint[0] - startPoint[0]) >= Math.abs(endPoint[1] - startPoint[1]) && currentNum > 0) {
        currentNum -= 1;
      }
    }

    this.setData({
      currentNavtab: currentNum
    });
  },

  switchTab: function (e) {
    this.setData({
      currentNavtab: e.currentTarget.dataset.idx
    });
  },


  callEvent: function (e) {
    console.log(e)
    wx.makePhoneCall({
      phoneNumber: this.data.phoneNum
    })
  },

  goDeatailEvent: function () {
    wx.navigateTo({
      url: '../orderManage/orderDeatail/orderDeatail'
    })
  },

  callback: function(res){
    console.log(res);
    this.setData({
      tempPrice : res
    })
  },

  getPrice:function(InDate, InSession,OutDate,OutSession,hallNo){
    var that = this;
    //console.log(InDate, InSession, OutDate, OutSession)
    var price =0;
    wx.request({
      url: 'https://www.paintorange.com/price.php',//写自己的服务器
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      data: {
        InDate: InDate,
        InSession: InSession,
        OutDate: OutDate,
        OutSession: OutSession,
        hallNo:hallNo
      },
      success: function (res) {
        //console.log("res:"+res.data);
       // return typeof callback == "function" && callback(res.data)        /*
        setTimeout(() => {
          wx.hideLoading();
        }, 100);
        that.setData({
          tempPrice: res.data
        })
      },
      fail: function () {
        //console.log("fail")
      }

    })
  },

  // 加载
  onLoad: function () {
    wx.setNavigationBarTitle({
      title: '订单管理'
    })
    var that = this
    //更新数据
    that.setData({
    })
  },
  onShow:function(){
    var that = this;
    if (app.globalData.isSubmit){
      wx.request({
        url: 'https://www.paintorange.com/bill.php',//写自己的服务器
        header: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        method: "POST",
        data: {
          name: app.globalData.name,
          phone: app.globalData.phone
        },
        success: function (res) {
          //console.log(res.data);
                var billToUse = [];
                for (var i = 0; i < res.data.length; i++) {
                    billToUse.push(res.data[i]);
                    if (res.data[i].hallNo == "X01") {
                      billToUse[billToUse.length - 1].hallName = '小和山一号馆'
                    } else if (res.data[i].hallNo == "X02") {
                      billToUse[billToUse.length - 1].hallName = '小和山二号馆'
                    } else if (res.data[i].hallNo == "Z02") {
                      billToUse[billToUse.length - 1].hallName = '紫金港一号馆'
                    }
                }
          that.setData({
            billToUse: billToUse
          }) 
          console.log(that.data.billToUse)
          wx.request({
            url: 'https://www.paintorange.com/foodorder.php',//写自己的服务器
            header: {
              "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            data: {
            },
            success: function (foodorder) {
              //console.log(that.data.billToUse)
              var x = that.data.billToUse
              
                for (var i = 0; i < x.length; i++) {
                  x[i].food = ""
                  x[i].foodPrice = 0;
                  if ("bhNo" in x[i]) {
                  for (var j = 0; j < foodorder.data.length; j++) {
                    if (x[i].bhNo == foodorder.data[j].bhNo) {
                      x[i].food = foodorder.data[j].foodName
                      x[i].foodPrice = foodorder.data[j].price
                    }
                  }
                }
                  x[i].totalPrice = x[i].price-(-(x[i].foodPrice-x[i].cut))
              }
              
              that.setData({
                billToUse:x
              })
              var roomNames = ['麻将房','私人影院','桌游室'];
              var getroomnamefromroom = that.data.billToUse;
              for (var i = 0; i < getroomnamefromroom.length;i++){
                if (getroomnamefromroom[i].InTime !== undefined && getroomnamefromroom[i].OutTime !== undefined){
                  getroomnamefromroom[i].roomName = roomNames[parseInt(getroomnamefromroom[i].roomNo)-1]
                  console.log(getroomnamefromroom[i].roomName)
                }
              }
              that.setData({
                billToUse: getroomnamefromroom
              })
              console.log(that.data.billToUse)
            },
            fail : function(e){

            }
          })              
        },
        fail: function () {
          console.log("fail")
        }
      })

      wx.request({
        url: 'https://www.paintorange.com/billNew.php',//写自己的服务器
        header: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        method: "POST",
        data: {
          name: app.globalData.name,
          phone: app.globalData.phone
        },
        success: function (res) {
          console.log(res.data);
          var billNewOrder = [];
          for (var i = 0; i < res.data.length; i++) {
              billNewOrder.push(res.data[i]);
              if (res.data[i].hallNo == "X01") {
                billNewOrder[billNewOrder.length - 1].hallName = '小和山一号馆'
              } else if (res.data[i].hallNo == "X02") {
                billNewOrder[billNewOrder.length - 1].hallName = '小和山二号馆'
              } else if (res.data[i].hallNo == "Z02") {
                billNewOrder[billNewOrder.length - 1].hallName = '紫金港一号馆'
              }
          }
          that.setData({
            billNewOrder: billNewOrder
          })
          var roomNames = ['麻将房', '私人影院', '桌游室']
          var getroomnamefromroom = that.data.billNewOrder;
          for (var i = 0; i < getroomnamefromroom.length; i++) {
            if (getroomnamefromroom[i].InTime !== undefined && getroomnamefromroom[i].OutTime !== undefined) {
              getroomnamefromroom[i].roomName = roomNames[parseInt(getroomnamefromroom[i].roomNo)-1]
            }
          }
          that.setData({
            billNewOrder: getroomnamefromroom
          })
         
        },
        fail: function () {
          console.log("fail")
        }
      })
    }
  },

  

  calculatePrice2: function (InDate, InSession, OutDate,OutSession,hallNo) {
    var that = this;
    var session =["凌晨场","白天场","夜晚场"]

    var startTime = new Date(InDate)
    var tempTime = new Date(InDate)
    var endTime = new Date(OutDate)
    var tempBuySession = []
    if ((endTime.getTime() - startTime.getTime()) == 0) {
      for (var i = session.indexOf(InSession); i <= session.indexOf(OutSession); i++) {
        var x = {}
        x.checkDate = InDate;
        x.checkSession = session[i];
        x.price = 0
        tempBuySession.push(x)
      }
    }
    while ((endTime.getTime() - tempTime.getTime()) >= 0) {
      if (startTime.getTime() != tempTime.getTime() && endTime.getTime() != tempTime.getTime()) {
        for (var i = 0; i < session.length; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      else if (startTime.getTime() != tempTime.getTime() && endTime.getTime() == tempTime.getTime()) {
        for (var i = 0; i <session.indexOf(OutSession) + 1; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      else if (startTime.getTime() == tempTime.getTime() && endTime.getTime() != tempTime.getTime()) {
        for (var i = session.indexOf(InSession); i < session.length; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      tempTime.setDate(tempTime.getDate() + 1);
    }

    for (var i = 0; i < tempBuySession.length; i++) {
      for (var j = 0; j < app.globalData.price.length; j++) {
        var tt = new Date(tempBuySession[i].checkDate);
        if (hallNo == app.globalData.price[j].hallNo &&
          (tt.getDay() == app.globalData.price[j].week || tt.getDay() == app.globalData.price[j].week - 7) &&
          tempBuySession[i].checkSession == app.globalData.price[j].session) {
          tempBuySession[i].price = app.globalData.price[j].price;
        }
      }
    }
    var pp = 0;
    for (var i = 0; i < tempBuySession.length; i++) {
      pp += tempBuySession[i].price;
    }

    /**计算优惠 */
    var cut = 0;
    if (tempBuySession.length >= 2) {
      if (hallNo == 'X01' || hallNo == 'X02') {
        if (tempBuySession.length >= 3) { cut = 500 }
        else { cut = 200 }
      }
      else if (hallNo == 'Z01') {
        if (tempBuySession.length >= 3) { cut = 300 }
        else { cut = 200 }
      }
    }

    pp-=cut;
    return pp;
  }
})
