var app = getApp();
Page({
  data: {
    items: [
      {
        name: '凌晨场',
        value: '凌晨场',
        time: "00:00 ~ 9:00",
        checked:"true"
      },
      {
        name: '白天场',
        value: '白天场',
        time: "10:00 ~ 16:00"
      },
      {
        name: '夜晚场',
        value: '夜晚场',
        time: "17:00 ~ 23:00"
      }
    ],
    items2: [
      {
        name: '凌晨场',
        value: '凌晨场',
        time: "00:00 ~ 9:00",
        checked: "true"
      },
      {
        name: '白天场',
        value: '白天场',
        time: "10:00 ~ 16:00"
      },
      {
        name: '夜晚场',
        value: '夜晚场',
        time: "17:00 ~ 23:00"
      }
    ],
    checkSession:
    {
      checkInSession:"夜晚场",
      checkOutSession:"夜晚场"
    }
    //checkSession:"凌晨场",
    //checkOutSession:"凌晨场"
  },
  radioChange: function (e) {
    var that = this;
    console.log('radio发生change事件，携带value值为：', e.detail.value)
    var items = this.data.items;
    for (var i = 0, len = items.length; i < len; ++i) {
      items[i].checked = items[i].value == e.detail.value
    }
    let checkInSession = "checkSession.checkInSession"
    that.setData({
      items: items,
      [checkInSession]: e.detail.value
    });
    console.log('checkInSession的值是：', that.data.checkSession.checkInSession)
    app.globalData.checkSession.checkInSession = that.data.checkSession.checkInSession
    that.calculatePrice();
  },

  radioChange2: function (e) {
    var that = this;
    console.log('radio发生change事件，携带value值为：', e.detail.value)

    var checkSession = this.data.checkSession;
    var items2 = this.data.items2;
    for (var i = 0, len = items2.length; i < len; ++i) {
      items2[i].checked = items2[i].value == e.detail.value
    }
    let checkOutSession = "checkSession.checkOutSession"
    that.setData({
      items2: items2,
      [checkOutSession]: e.detail.value
    }); 
    console.log('checkOutSession的值是：', that.data.checkSession.checkOutSession)
    app.globalData.checkSession.checkInSession = that.data.checkSession.checkInSession
    that.calculatePrice();


  },

  getBack: function(){
    var checkSession = this.data.checkSession;
    app.globalData.checkSession = checkSession;
    console.log(app.globalData.checkSession);
    wx.switchTab({
      url: '../../pages/reservation/reservation'
    });
  }
})
