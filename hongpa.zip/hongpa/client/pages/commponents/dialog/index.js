

function e(e) {
    var t = e.id, o = e.pageCtx;
    if (!o) {
        var r = getCurrentPages();
        o = r[r.length - 1];
    }
    return o.selectComponent && o.selectComponent("#" + t);
}

function t() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return r({}, n.default, e);
}

function o(o, n) {
    var i = t(o), a = e({
        id: i.id,
        pageCtx: n
    });
    return a ? new Promise(function(e, t) {
        a.setData(r({}, i, {
            _showSpaceBoxDialog: !0,
            _promiseFunc: {
                resolve: e,
                reject: t
            }
        }));
    }) : (console.error("无法找到对应的dialog组件，请于 wxml 中声明 dialog 自定义组件，并指定其 id 属性，并且在调用 Dialog 构造函数时应该指定和前面一样的 id"), 
    Promise.reject({
        type: "component error"
    }));
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var o = arguments[t];
        for (var r in o) Object.prototype.hasOwnProperty.call(o, r) && (e[r] = o[r]);
    }
    return e;
}, n = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./dialogConfig"));

o.close = function(o, r) {
    var n = e({
        id: t(o).id,
        pageCtx: r
    });
    n && n.setData({
        _dialogContentVisibility: !1,
        _showSpaceBoxDialog: !1,
        _promiseFunc: null
    });
}, exports.default = o;