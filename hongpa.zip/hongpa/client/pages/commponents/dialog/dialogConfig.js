Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = {
    title: "提示",
    content: "",
    hideCancelButton: !1,
    confirmButtonText: "确定",
    confirmButtonStyle: "",
    cancelButtonText: "取消",
    cancelButtonStyle: "",
    titleStyle: "",
    maskClosable: !1,
    confirmButtonOpenType: "",
    cancelButtonOpenType: ""
};

exports.default = t;