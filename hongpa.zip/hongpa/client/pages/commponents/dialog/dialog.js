

function t(t, o, e) {
    return o in t ? Object.defineProperty(t, o, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[o] = e, t;
}

var o = Object.assign || function(t) {
    for (var o = 1; o < arguments.length; o++) {
        var e = arguments[o];
        for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    }
    return t;
}, e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("./dialogConfig")), i = function() {};

Component({
    properties: {
        _showSpaceBoxDialog: {
            type: Boolean,
            value: !1,
            observer: function(t, o) {
                t && this.updatePosition("_showSpaceBoxDialog", t);
            }
        }
    },
    data: o({
        _windowHeight: "100vh",
        _showSpaceBoxDialog: !1,
        _dialogContentVisibility: !1,
        _dialogTopPos: "45%",
        _promiseFunc: {}
    }, e.default),
    ready: function() {
        this.sysInfo = wx.getSystemInfoSync(), this.query = this.createSelectorQuery();
    },
    methods: {
        updatePosition: function(o, e) {
            var i = this;
            i.setData({
                _dialogContentVisibility: !1
            }), i.query && (i.query.select("#" + i.data.id + "_component ._space-box-dialog-container").boundingClientRect(), 
            i.query.exec(function(n) {
                if (n && n[0]) {
                    var a;
                    i.setData((a = {}, t(a, o, e), t(a, "_dialogContentVisibility", !0), t(a, "_dialogTopPos", (i.sysInfo.windowHeight - n[0].height - 65) / 2), 
                    a));
                }
            }));
        },
        onMaskClick: function() {
            this.data.maskClosable && this.setData({
                _promiseFunc: {},
                _showSpaceBoxDialog: !1,
                _dialogContentVisibility: !1
            });
        },
        onButtonClick: function(t) {
            var o = this, e = t.currentTarget, n = (void 0 === e ? {} : e).dataset, a = void 0 === n ? {} : n, s = o.data._promiseFunc || {}, r = s.resolve, c = void 0 === r ? i : r, l = s.reject, u = void 0 === l ? i : l;
            "confirm" === a.type ? c({
                type: "confirm"
            }) : u({
                type: "cancel"
            }), o.setData({
                _promiseFunc: {},
                _showSpaceBoxDialog: !1,
                _dialogContentVisibility: !1
            });
        },
        catchTouchMove: function() {}
        
    }
});