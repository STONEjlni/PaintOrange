// pages/chooseTime/chooseTime.js
var app = getApp();

var Moment = require("../../utils/moment.js");
var DATE_LIST = [];
var DATE_YEAR = new Date().getFullYear();
var DATE_MONTH = new Date().getMonth() + 1;
var DATE_DAY = new Date().getDate();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    hall: app.globalData.hall,
    checkDateSession: [],
    buySession: [],
    session: ["凌晨场", "白天场", "夜晚场"],
    items: [
      {
        name: '凌晨场',
        value: '凌晨场',
        time: "00:00 ~ 9:00",
        checked: "true"
      },
      {
        name: '白天场',
        value: '白天场',
        time: "10:00 ~ 16:00"
      },
      {
        name: '夜晚场',
        value: '夜晚场',
        time: "17:00 ~ 23:00"
      }
    ],
    items2: [
      {
        name: '凌晨场',
        value: '凌晨场',
        time: "00:00 ~ 9:00",
        checked: "true"
      },
      {
        name: '白天场',
        value: '白天场',
        time: "10:00 ~ 16:00"
      },
      {
        name: '夜晚场',
        value: '夜晚场',
        time: "17:00 ~ 23:00"
      }
    ],


    checkInDate: "",
    checkOutDate: "",
    checkSession: {
      checkInSession: "夜晚场",
      checkOutSession: "夜晚场"
    },
    isInSessionOk:[false, false, false],
    isOutSessionOk: [false, false, false],
    isInSessionChecked:[false,false,false],
    isOutSessionChecked: [false, false, false],
    hallPrice:0
  },

  isExistInArr: function (_array, _element) {//判断某个元素是否在数组中
    if (!_array || !_element) return false;
    if (!_array.length) {
      return (_array == _element);
    }
    for (var i = 0; i < _array.length; i++) {
      if (_element == _array[i]) return true;
    }
    return false;
  },

  distinct: function (_array) {//除去数组重复的部分
    if (!_array || !_array.length) return _array;
    var newArray = new Array();
    for (var i = 0; i < _array.length; i++) {
      var oEl = _array[i];
      if (!oEl || this.isExistInArr(newArray, oEl)) continue;
      newArray[newArray.length] = oEl;
    }
    return newArray;
  },

  getBanDate: function () {
    var Session = ['凌晨场', '白天场', '夜晚场']
    var that = this;
    console.log(app.globalData.hallNo)
   
    wx.request({
      url: 'https://www.paintorange.com/data.php', //真实的接口地址
      method: 'POST',
      data: {
        hallNo:app.globalData.hallNo
      },
      header: { 'content-type': 'application/x-www-form-urlencoded' },
     
      success: function (res) {
        console.log(res.data)
        //var temp = [];
        //temp.push(res.data[0].InDate)
        var temp = [];
        var tempLimit = [];
        //temp.push(res.data[0].InDate)
        for (var i = 0; i < res.data.length; i++) {
          if (res.data[i] != null) {
            var start = res.data[i].InDate;
            var end = res.data[i].OutDate;
            var startTime = new Date(start)
            var endTime = new Date(end)

            if ((endTime.getTime() - startTime.getTime()) > 0) {//跨天的情况看看两端能否加入
              if (res.data[i].InSession == '凌晨场') {//入住天为凌晨场
                var year = startTime.getFullYear();
                var month = startTime.getMonth().toString().length == 1 ? "0" + (startTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
                var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
                var x = year + "-" + month + "-" + day;
                temp.push(year + "-" + month + "-" + day);
              } else {//入住天不为凌晨场
                var index = []//当天哪些场次被预定了
                for (var k = Session.indexOf(res.data[i].InSession); k < Session.length; k++) {
                  index.push(Session[k])
                }
                for (var j = 0; j < res.data.length; j++) {//单场均被预定的情况
                  if (res.data[j] != null) {
                    if (res.data[j].OutDate == start && res.data[j].InDate != start) {
                      for (var k = 0; k <= Session.indexOf(res.data[j].OutSession); k++) {
                        index.push(Session[k])
                      }
                    }
                    if (res.data[j].InDate == start && res.data[j].OutDate != start) {
                      for (var k = Session.indexOf(res.data[j].InSession); k < Session.length; k++) {
                        index.push(Session[k])
                      }
                    }
                    if (res.data[j].OutDate == start && res.data[j].OutDate == start) {
                      for (var k = Session.indexOf(res.data[j].InSession); k <= Session.indexOf(res.data[j].OutSession); k++) {
                        index.push(Session[k])
                      }
                    }
                  }
                }
                index = that.distinct(index);
                if (index.length == 3) {//该日期场次全被占
                  var year = startTime.getFullYear();
                  var month = startTime.getMonth().toString().length == 1 ? "0" + (startTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
                  var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
                  var x = year + "-" + month + "-" + day;
                  temp.push(year + "-" + month + "-" + day);

                } else {
                  var year = startTime.getFullYear();
                  var month = startTime.getMonth().toString().length == 1 ? "0" + (startTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
                  var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
                  var x = {}
                  x.limitDate = year + "-" + month + "-" + day;
                  x.checkedSession = [];
                  x.checkedSession = index;
                  tempLimit.push(x);
                }
              }

              if (res.data[i].OutSession == '夜晚场') {//离开天为夜晚场
                var year = endTime.getFullYear();
                var month = endTime.getMonth().toString().length == 1 ? "0" + (endTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
                var day = endTime.getDate().toString().length == 1 ? "0" + endTime.getDate() : endTime.getDate();
                var x = year + "-" + month + "-" + day;
                temp.push(year + "-" + month + "-" + day);
              } else {//离开天不为凌晨场
                var index = []//当天哪些场次被预定了
                for (var k = 0; k <= Session.indexOf(res.data[i].OutSession); k++) {
                  index.push(Session[k])
                }
                for (var j = 0; j < res.data.length; j++) {//单场均被预定的情况
                  if (res.data[j] != null) {
                    if (res.data[j].InDate == end && res.data[j].InDate == end) {
                      for (var k = Session.indexOf(res.data[j].InSession); k < Session.length; k++) {
                        index.push(Session[k])
                      }
                    }
                    if (res.data[j].OutDate == start && res.data[j].InDate != start) {
                      for (var k = 0; k <= Session.indexOf(res.data[j].InSession); k++) {
                        index.push(Session[k])
                      }
                    }
                    if (res.data[j].OutDate == start && res.data[j].OutDate == start) {
                      for (var k = Session.indexOf(res.data[j].InSession); k <= Session.indexOf(res.data[j].OutSession); k++) {
                        index.push(Session[k])
                      }
                    }
                  }
                }
                index = that.distinct(index);
                if (index.length == 3) {//该日期场次全被占
                  var year = endTime.getFullYear();
                  var month = endTime.getMonth().toString().length == 1 ? "0" + (endTime.getMonth() + 1).toString() : (endTime.getMonth() + 1);
                  var day = endTime.getDate().toString().length == 1 ? "0" + endTime.getDate() : endTime.getDate();
                  var x = year + "-" + month + "-" + day;
                  temp.push(year + "-" + month + "-" + day);

                } else {
                  var year = endTime.getFullYear();
                  var month = endTime.getMonth().toString().length == 1 ? "0" + (endTime.getMonth() + 1).toString() : (endTime.getMonth() + 1);
                  var day = endTime.getDate().toString().length == 1 ? "0" + endTime.getDate() : endTime.getDate();
                  var x = {}
                  x.limitDate = year + "-" + month + "-" + day;
                  x.checkedSession = [];
                  x.checkedSession = index;
                  tempLimit.push(x);
                }

              }

            }

            while ((endTime.getTime() - startTime.getTime()) > 0) {//跨天将中间的日期加入banDate
              //console.log("mmm")
              var year = startTime.getFullYear();
              var month = startTime.getMonth().toString().length == 1 ? "0" + (startTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
              var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
              var x = year + "-" + month + "-" + day;
              if (x != start && x != end) {
                temp.push(year + "-" + month + "-" + day);
              }
              //temp.push(year + "-" + month + "-" + day);
              startTime.setDate(startTime.getDate() + 1);
            }
            //再次赋值
            var startTime = new Date(start)
            var endTime = new Date(end)


            if ((endTime.getTime() - startTime.getTime()) == 0) {//整天的情况
              if (res.data.InSession == '凌晨场' && res.data.OutSession == '夜晚场') {
                var year = startTime.getFullYear();
                var month = startTime.getMonth().toString().length == 1 ? "0" + (startTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
                var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
                temp.push(year + "-" + month + "-" + day);
              } else {
                var index = []//当天哪些场次被预定了
                for (var k = Session.indexOf(res.data[i].InSession); k <= Session.indexOf(res.data[i].OutSession); k++) {
                  index.push(Session[k])
                }
                for (var j = 0; j < res.data.length; j++) {//单场均被预定的情况
                  if (res.data[j] != null) {
                    if (res.data[j].InDate == start && res.data[j].OutDate != start) {
                      for (var k = Session.indexOf(res.data[j].InSession); k < Session.length; k++) {
                        index.push(Session[k])
                      }
                    }
                    if (res.data[j].OutDate == start && res.data[j].InDate != start) {
                      for (var k = Session.length - 1; k >= Session.indexOf(res.data[j].OutSession); k--) {
                        index.push(Session[k])
                      }
                    }
                    if (res.data[j].OutDate == start && res.data[j].OutDate == start) {
                      for (var k = Session.indexOf(res.data[j].InSession); k <= Session.indexOf(res.data[j].OutSession); k++) {
                        index.push(Session[k])
                      }
                    }
                  }
                }
                index = that.distinct(index);
                if (index.length == 3) {//该日期场次全被占
                  var year = startTime.getFullYear();
                  var month = startTime.getMonth().toString().length == 1 ? "0" + (startTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
                  var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
                  var x = year + "-" + month + "-" + day;
                  temp.push(year + "-" + month + "-" + day);

                } else {
                  var year = startTime.getFullYear();
                  var month = startTime.getMonth().toString().length == 1 ? "0" + (startTime.getMonth() + 1).toString() : (startTime.getMonth() + 1);
                  var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
                  var x = {}
                  x.limitDate = year + "-" + month + "-" + day;
                  x.checkedSession = [];
                  x.checkedSession = index;
                  tempLimit.push(x);
                }
              }
            }
          }

        }

       /**到此为止temp代表的banDate和tempList代表的tempLimit都已经计算完毕，除功能房外 */

        var times = ['8:30','9:00','9:30','10:00', '10:30','11:00', '11:30','12:00','12:30', '13:00','13:30', '14:00','14:30','15:00','15:30', '16:00','16:30','17:00','17:30','18:00', '18:30', '19:00','20:30', '21:00', '21:30']
        var today = Moment(new Date()).add(0, 'day').format('YYYY-MM-DD');
        console.log(today)
          wx.request({
            url: 'https://www.paintorange.com/data2.php',//写自己的服务器
            header: { 'content-type': 'application/x-www-form-urlencoded' },
            method: "POST",
            data: {
              today:today,
              hallNo:app.globalData.hallNo
            },
            success: function (bantime) {
              console.log(bantime.data)
              var banTimeList =[]
              for(var el=0;el<bantime.data.length;el++){
                var inindex = times.indexOf(bantime.data[el].InTime);
                var outindex = times.indexOf(bantime.data[el].OutTime);
                for (var indexindex = inindex;indexindex<=outindex;indexindex++){
                  banTimeList.push(indexindex);
                }
              }
              console.log(banTimeList)


              if(!that.isExistInArr(temp,today)){
                var ifRoomBan = false;
                var indexRoom = -1;
                for (var tl = 0; tl < tempLimit.length; tl++) {
                  if (tempLimit[tl].limitDate == today) {
                    ifRoomBan = true;
                    indexRoom = tl
                  }
                }

                if (ifRoomBan) {
                  for (var bl = 0; bl < banTimeList.length; bl++) {
                    if (banTimeList[bl] == 0 || banTimeList[bl] == 1) {
                      tempLimit[indexRoom].checkedSession.push("凌晨场")
                    }
                    if (banTimeList[bl] <= 15 && banTimeList[bl] >= 3) {
                      tempLimit[indexRoom].checkedSession.push("白天场")
                    }
                    if (banTimeList[bl] <= 24 && banTimeList[bl] >= 17) {
                      tempLimit[indexRoom].checkedSession.push("夜晚场")
                    }
                  }
                  tempLimit[indexRoom].checkedSession = that.distinct(tempLimit[indexRoom].checkedSession)
                  if (tempLimit[indexRoom].checkedSession.length >= 3) {
                    temp.push(tempLimit[indexRoom].limitDate)
                    tempLimit.splice(indexRoom, 1)
                  }
                } else {
                  var x = {}
                  x.limitDate = today
                  x.checkedSession = []
                  for (var bl = 0; bl < banTimeList.length; bl++) {
                    if (banTimeList[bl] == 0 || banTimeList[bl] == 1) {
                      x.checkedSession.push("凌晨场")
                    }
                    if (banTimeList[bl] <= 15 && banTimeList[bl] >= 3) {
                      x.checkedSession.push("白天场")
                    }
                    if (banTimeList[bl] <= 24 && banTimeList[bl] >= 17) {
                      x.checkedSession.push("夜晚场")
                    }
                  }
                  x.checkedSession = that.distinct(x.checkedSession)
                  if(x.checkedSession.length >=3){
                    temp.push(x.limitDate)
                  }else{
                    tempLimit.push(x)
                  }
                  console.log(x)
                }

                
                
                
              }

              



              temp = that.distinct(temp);
              app.globalData.banDate = temp;
              console.log("禁止的日期: " + app.globalData.banDate);
              tempLimit = that.distinct(tempLimit);
              app.globalData.limitDate = tempLimit;
              for (var m = 0; m < app.globalData.limitDate.length; m++) {
                console.log("限制的日期: " + app.globalData.limitDate[m].limitDate + app.globalData.limitDate[m].checkedSession);
              }

              /*默认日期*/
              var iteration = 0
              while (that.isExistInArr(app.globalData.banDate, app.globalData.checkInDate)) {
                app.globalData.checkInDate = Moment(new Date()).add(iteration, 'day').format('YYYY-MM-DD');
                iteration += 1
              }
              app.globalData.checkOutDate = app.globalData.checkInDate;

              /**默认时间段 */

              var ifLimit = false
              var limitIndex = 0;
              for (var i = 0; i < app.globalData.limitDate.length; i++) {
                if (app.globalData.checkInDate == app.globalData.limitDate[i].limitDate) {
                  ifLimit = true;
                  limitIndex = i;
                }
              }

              //console.log(that.globalData.limitDate[limitIndex]);
              if (ifLimit) {
                for (var t = 0; t < Session.length; t++) {
                  if (!that.isExistInArr(app.globalData.limitDate[limitIndex].checkedSession, Session[t])) {
                    app.globalData.checkSession.checkInSession = Session[t];
                    app.globalData.checkSession.checkOutSession = Session[t]
                    //console.log(Session[t])
                    //ifLimit = false;
                  }
                }
              }






              /**入住Session初始化，限制 */
              var ifInLimit = false
              var InlimitIndex = 0;
              //console.log("fff" + app.globalData.checkInDate);
              for (var i = 0; i < app.globalData.limitDate.length; i++) {
                if (app.globalData.checkInDate == app.globalData.limitDate[i].limitDate) {
                  ifInLimit = true;
                  InlimitIndex = i;
                }
              }

              if (ifInLimit) {
                var r = []
                for (var t = 0; t < Session.length; t++) {
                  if (that.isExistInArr(app.globalData.limitDate[InlimitIndex].checkedSession, Session[t])) {

                    r[t] = true;

                    //console.log(Session[t])
                    //ifLimit = false;
                  } else {
                    r[t] = false

                  }
                }
                //console.log(r)
                that.setData({
                  isInSessionOk: r
                })

              } else {
                that.setData({
                  isInSessionOk: [false, false, false]
                });
              }
              //console.log(that.data.isInSessionOk)

              var r = []
              for (var i = 0; i < Session.length; i++) {
                if (app.globalData.checkSession.checkInSession == Session[i]) {
                  r[i] = true;
                } else {
                  r[i] = false
                }
              }

              that.setData({
                isInSessionChecked: r
              });


              /*离开场次初始化，限制*/
              var ifOutLimit = false
              var OutlimitIndex = 0;
              //    console.log("fff" + app.globalData.checkOutDate);
              for (var i = 0; i < app.globalData.limitDate.length; i++) {
                if (app.globalData.checkOutDate == app.globalData.limitDate[i].limitDate) {
                  ifOutLimit = true;
                  OutlimitIndex = i;
                }
              }

              if (ifOutLimit) {
                var r = []
                for (var t = 0; t < Session.length; t++) {
                  if (that.isExistInArr(app.globalData.limitDate[InlimitIndex].checkedSession, Session[t])) {

                    r[t] = true;

                    //console.log(Session[t])
                    //ifLimit = false;
                  } else {
                    r[t] = false

                  }
                }
                //console.log(r)
                that.setData({
                  isOutSessionOk: r
                })
                //console.log(that.data.isSessionOk)
              } else {
                that.setData({
                  isOutSessionOk: [false, false, false]
                });
              }

              var r = []
              for (var i = 0; i < Session.length; i++) {
                if (app.globalData.checkSession.checkOutSession == Session[i]) {
                  r[i] = true;
                } else {
                  r[i] = false
                }
              }

              that.setData({
                isOutSessionChecked: r
              });

             
              that.setData({
                checkInDate: app.globalData.checkInDate,
                checkOutDate: app.globalData.checkOutDate
              });
              that.setData({
                checkSession: app.globalData.checkSession,
              })

              /**计算价格 */
              that.calculatePrice2();


            },
            fail: function () {
              console.log("fail")
            }

          })
        
        

      },
      fail: function (err) {
        console.log(err)
      }
    })


  },

limitSession:function(){//场次限制，初始化
  var that = this
  var Session = ["凌晨场","白天场","夜晚场"]
  var ifInLimit = false
  var InlimitIndex = 0;
  //console.log("fff" + app.globalData.checkInDate);
  for (var i = 0; i < app.globalData.limitDate.length; i++) {
    if (app.globalData.checkInDate == app.globalData.limitDate[i].limitDate) {
      ifInLimit = true;
      InlimitIndex = i;
    }
  }

  if (ifInLimit) {
    var r = []
    for (var t = 0; t < Session.length; t++) {
      if (that.isExistInArr(app.globalData.limitDate[InlimitIndex].checkedSession, Session[t])) {

        r[t] = true;

        //console.log(Session[t])
        //ifLimit = false;
      } else {
        r[t] = false

      }
    }
    //console.log(r)
    that.setData({
      isInSessionOk: r
    })

  } else {
    that.setData({
      isInSessionOk: [false, false, false]
    });
  }
  //console.log(that.data.isInSessionOk)

  var r = []
  for (var i = 0; i < Session.length; i++) {
    if (app.globalData.checkSession.checkInSession == Session[i]) {
      r[i] = true;
    } else {
      r[i] = false
    }
  }

  that.setData({
    isInSessionChecked: r
  });


  /*离开场次初始化，限制*/
  var ifOutLimit = false
  var OutlimitIndex = 0;
  //    console.log("fff" + app.globalData.checkOutDate);
  for (var i = 0; i < app.globalData.limitDate.length; i++) {
    if (app.globalData.checkOutDate == app.globalData.limitDate[i].limitDate) {
      ifOutLimit = true;
      OutlimitIndex = i;
    }
  }

  if (ifOutLimit) {
    var r = []
    for (var t = 0; t < Session.length; t++) {
      if (that.isExistInArr(app.globalData.limitDate[InlimitIndex].checkedSession, Session[t])) {

        r[t] = true;

        //console.log(Session[t])
        //ifLimit = false;
      } else {
        r[t] = false

      }
    }
    //console.log(r)
    that.setData({
      isOutSessionOk: r
    })
    //console.log(that.data.isSessionOk)
  } else {
    that.setData({
      isOutSessionOk: [false, false, false]
    });
  }

  var r = []
  for (var i = 0; i < Session.length; i++) {
    if (app.globalData.checkSession.checkOutSession == Session[i]) {
      r[i] = true;
    } else {
      r[i] = false
    }
  }

  that.setData({
    isOutSessionChecked: r
  });

},
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    //that.getBanDate();


    //设缓存缓存起来的日期
    wx.setStorage({
      key: 'ROOM_SOURCE_DATE',
      data: {
        checkInDate: app.globalData.checkInDate,
        checkOutDate: app.globalData.checkOutDate
      }
    });

    var Session = ['凌晨场', '白天场', '夜晚场']
    var today = Moment(new Date()).add(0, 'day').format('YYYY-MM-DD')
    console.log(today)

        that.getBanDate();


  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    let getDate = wx.getStorageSync("ROOM_SOURCE_DATE");
    that.setData({
      checkInDate: getDate.checkInDate,
      checkOutDate: getDate.checkOutDate
    });
    that.setData({
      checkSession: app.globalData.checkSession,
    })

    that.limitSession();
    that.calculatePrice2();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },



  radioChange: function (e) {
    //console.log('radio发生change事件，携带value值为：', e.detail.value)
    var that = this;
    var items = that.data.items;
    for (var i = 0, len = items.length; i < len; ++i) {
      items[i].checked = items[i].value == e.detail.value
    }
    let checkInSession = "checkSession.checkInSession"
    that.setData({
      items: items,
      [checkInSession]: e.detail.value
    });
    console.log('checkInSession的值是：', that.data.checkSession.checkInSession)
    app.globalData.checkSession.checkInSession = that.data.checkSession.checkInSession
    that.calculatePrice2();
  },

  radioChange2: function (e) {

    //console.log('radio发生change事件，携带value值为：', e.detail.value)

    var that = this;
    var checkSession = this.data.checkSession;
    var items2 = this.data.items2;
    for (var i = 0, len = items2.length; i < len; ++i) {
      items2[i].checked = items2[i].value == e.detail.value
    }
    let checkOutSession = "checkSession.checkOutSession"
    that.setData({
      items2: items2,
      [checkOutSession]: e.detail.value
    });
    console.log('checkOutSession的值是：', that.data.checkSession.checkOutSession)
    app.globalData.checkSession.checkOutSession = that.data.checkSession.checkOutSession
    that.calculatePrice2();
  },

  getBack: function () {
    var that = this;
    if(that.data.hallPrice != 0){
      var checkSession = this.data.checkSession;
      app.globalData.checkSession = checkSession;

      var checkInDate = this.data.checkInDate;
      app.globalData.checkInDate = checkInDate;

      var checkOutDate = this.data.checkOutDate;
      app.globalData.checkOutDate = checkOutDate;

      console.log("app.globalData.checkOutDate" + app.globalData.checkOutDate);
      console.log("app.globalData.checkInDate" + app.globalData.checkInDate);

      //console.log(app.globalData.checkSession);
      wx.navigateTo({
        url: '../order/order'
      });
    }
    else{
      return;
    }
    
  },
  getradio: function (e) {
    let index = e.currentTarget.dataset.id;
    let radio = this.data.radio;
    for (let i = 0; i < radio.length; i++) {
      this.data.radio[i].checked = false;
    }
    if (radio[index].checked) {
      this.data.radio[index].checked = false;
    } else {
      this.data.radio[index].checked = true;
    }
    let userRadio = radio.filter((item, index) => {
      return item.checked == true;
    })
    this.setData({ radio: this.data.radio })
    console.log(userRadio)
  },

  calculatePrice:function(){//计算价格的函数
    var that = this;
    //console.log(InDate, InSession, OutDate, OutSession)
    var price = 0;
    wx.request({
      url: 'https://www.paintorange.com/price.php',//写自己的服务器
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      data: {
        InDate: app.globalData.checkInDate,
        InSession: app.globalData.checkSession.checkInSession,
        OutDate: app.globalData.checkOutDate,
        OutSession: app.globalData.checkSession.checkOutSession,
        hallNo: app.globalData.hallNo
      },
      success: function (res) {
        //console.log("res:" + res.data);
        // return typeof callback == "function" && callback(res.data)        /*
        that.setData({
          hallPrice: res.data
        })
      },
      fail: function () {
        //console.log("fail")
      }

    })
  },

  calculatePrice2:function(){
    this.setData({
      checkInDate: app.globalData.checkInDate,
      checkOutDate: app.globalData.checkOutDate,
      checkSession: app.globalData.checkSession,
    })
    var that = this;
    var tempName = ''
    var tempLocation = ''
    for (var i = 0; i < app.globalData.hall.length; i++) {
      if (app.globalData.hall[i].No == app.globalData.hallNo) {
        tempLocation = app.globalData.hall[i].location
        tempName = app.globalData.hall[i].name
      }
    }
    that.setData({
      location: tempLocation,
      hallName: tempName
    })

    var startTime = new Date(that.data.checkInDate)
    var tempTime = new Date(that.data.checkInDate)
    var endTime = new Date(that.data.checkOutDate)
    var tempBuySession = []
    if ((endTime.getTime() - startTime.getTime()) == 0) {
      for (var i = that.data.session.indexOf(that.data.checkSession.checkInSession); i <= that.data.session.indexOf(that.data.checkSession.checkOutSession); i++) {
        var x = {}
        x.checkDate = that.data.checkInDate;
        x.checkSession = that.data.session[i];
        x.price = 0
        tempBuySession.push(x)
      }
    }
    while ((endTime.getTime() - tempTime.getTime()) >= 0) {
      if (startTime.getTime() != tempTime.getTime() && endTime.getTime() != tempTime.getTime()) {
        for (var i = 0; i < that.data.session.length; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = that.data.session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      else if (startTime.getTime() != tempTime.getTime() && endTime.getTime() == tempTime.getTime()) {
        for (var i = 0; i < that.data.session.indexOf(that.data.checkSession.checkOutSession) + 1; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = that.data.session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      else if (startTime.getTime() == tempTime.getTime() && endTime.getTime() != tempTime.getTime()) {
        for (var i = that.data.session.indexOf(that.data.checkSession.checkInSession); i < that.data.session.length; i++) {
          var year = tempTime.getFullYear();
          var month = tempTime.getMonth().toString().length == 1 ? "0" + (tempTime.getMonth() + 1).toString() : (tempTime.getMonth() + 1);
          var day = tempTime.getDate().toString().length == 1 ? "0" + tempTime.getDate() : tempTime.getDate();
          var ddd = year + "-" + month + "-" + day;
          var x = {};
          x.checkDate = ddd
          x.checkSession = that.data.session[i];
          x.price = 0
          tempBuySession.push(x)
        }
      }
      tempTime.setDate(tempTime.getDate() + 1);
    }

    for (var i = 0; i < tempBuySession.length; i++) {
      for (var j = 0; j < app.globalData.price.length; j++) {
        var tt = new Date(tempBuySession[i].checkDate);
        if (app.globalData.hallNo == app.globalData.price[j].hallNo &&
          (tt.getDay() == app.globalData.price[j].week || tt.getDay() == app.globalData.price[j].week - 7) &&
          tempBuySession[i].checkSession == app.globalData.price[j].session) {
          tempBuySession[i].price = app.globalData.price[j].price;
        }
      }
    }


    that.setData({
      buySession: tempBuySession
    })
    console.log(that.data.buySession)
    var pp = 0;
    for (var i = 0; i < that.data.buySession.length; i++) {
      pp += that.data.buySession[i].price;
    }
    that.setData({
      hallPrice: pp
    })
    for (var i = 0; i < that.data.buySession.length;i++){
      for(var j=0;j<app.globalData.limitDate;j++){
        if (that.isExistInArr(app.globalData.limitDate[j].checkDateSession, that.data.buySession[i].checkSession) && that.data.buySession[i].checkDate == app.globalData.limitDate[j].limitDate){
          that.setData({
            hallPrice:0
          })
        }
      }
    }
  }
})