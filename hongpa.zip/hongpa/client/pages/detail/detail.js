Page({
  data: {
    // input默认是1
    num: 1,
    // 使用data数据对象设置样式名
    minusStatus: 'disabled',
    focus: false,
    list: [
      {
        id: 'FirsTopping',
        name: '主食选择',
        open: true,
        food: [
          { value: 'Chiken', name: '鸡肉', checked: 'false' },
          { value: 'BreadedChiken', name: '面包鸡', checked: 'true' },
          { value: 'Pepperoni', name: '意大利辣香肠', checked: 'false' },
          { value: 'Garlic', name: '中国大蒜',checked: 'false'  },
          { value: 'RedBellPepper', name: '红色灯笼椒', checked: 'false'  },
          { value: 'Mushrooms', name: '新鲜小蘑菇', checked: 'false' },
        ]
      }
    ],
  list2:[
    {
      id: 'AdditionalTopping',
      name: '小菜选择',
      open: true,
      food: [
        { value: 'Pepperoni', name: '意大利辣香肠', checked: 'false' },
        { value: 'Garlic', name: '中国大蒜', checked: 'false' },
        { value: 'RedBellPepper', name: '红色灯笼椒', checked: 'false' },
        { value: 'Mushrooms', name: '新鲜小蘑菇', checked: 'false' },
      ]
    }
  ]
  },
  kindToggle: function (e) {
    var id = e.currentTarget.id, list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id == id) {
        list[i].open = !list[i].open
      } 
    }
    this.setData({
      list: list
    });
  },
  kindToggle: function (e) {
    var id = e.currentTarget.id, list2 = this.data.list2;
    for (var i = 0, len = list2.length; i < len; ++i) {
      if (list2[i].id == id) {
        list2[i].open = !list2[i].open
      }
    }
    this.setData({
      list2: list2
    });
  },
  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value)

    var items = this.data.items;
    for (var i = 0, len = items.length; i < len; ++i) {
      items[i].checked = items[i].value == e.detail.value
    }

    this.setData({
      items: items
    });
  }, 
  checkboxChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)

    var items = this.data.items, values = e.detail.value;
    for (var i = 0, lenI = items.length; i < lenI; ++i) {
      items[i].checked = false;

      for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
        if (items[i].value == values[j]) {
          items[i].checked = true;
          break
        }
      }
    }

    this.setData({
      items: items
    })
  },
  bindTextAreaBlur: function (e) {
    console.log(e.detail.value)
  },
  /* 点击减号 */	bindMinus: function () {
    var num = this.data.num;		
    // 如果大于1时，才可以减		
    if (num > 1) {			
      num --;		
    }		
    // 只有大于一件的时候，才能normal状态，否则disable状态		
    var minusStatus = num <= 1 ? 'disabled' : 'normal';		
    // 将数值与状态写回		
    this.setData({			
      num: num,			
      minusStatus: minusStatus		
      });	
  },	
    
    /* 点击加号 */	
    bindPlus: function() {		
      var num = this.data.num;		
      // 不作过多考虑自增1		
      num ++;		
      // 只有大于一件的时候，才能normal状态，否则disable状态		
      var minusStatus = num < 1 ? 'disabled' : 'normal';		
      // 将数值与状态写回		
      this.setData({			
        num: num,			
        minusStatus: minusStatus		
        });	
    },
    
    	/* 输入框事件 */	
      bindManual: function(e) {		
        var num = e.detail.value;		
        // 将数值与状态写回		
        this.setData({			
          num: num		
          });
  },

  addToOrder: function () {
    wx.navigateTo({
      url: '../../pages/order/order',
    })
  }

    
})

