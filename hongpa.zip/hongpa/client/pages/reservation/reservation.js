var app = getApp();
var config = require("../../config.js")
var Moment = require("../../utils/moment.js");
var DATE_LIST = [];
var DATE_YEAR = new Date().getFullYear();
var DATE_MONTH = new Date().getMonth() + 1;
var DATE_DAY = new Date().getDate();

Page({

  /**
   * 页面的初始数据
   */
  data: {

    host:"https://www.paintorange.com",
    timeSession : [
      {
        name:'凌晨场',
        value: 'lc',
        time:"00:00 ~ 9:00"
      },
      {
        name: '白天场',
        value: 'bt',
        time: "10:00 ~ 16:00"
      },
      {
        name: '夜晚场',
        value: 'yw',
        time: "17:00 ~ 23:00"
      }
    ],

    checkSession:{
      checkInSession: "夜晚场",
      checkOutSession: "夜晚场"
    },
    checkInDate: "",
    checkOutDate: "",
    peopleNo:0,


    /**
     * 总框架数据
     */
    //是否显示面板指示点
    indicatorDots: true,
    //存放滑动视图的current
    current: 0,
    //分页标签class条件判断的值
    tabArr: {
      tabCurrentIndex: 0
    },
    currentTab: 0,


    
    /**
     *小食数据
     */
    tempFoodBhNo : [] ,
    realTempFoodBhNo :'',
     goods: [{ "name": "火锅", 
               "type": "hotpot", 
               "foods": 
               [
                 { "name": "重庆小火锅", 
                           "price": 10,
                            "brand":"井格", 
                            "Count": 0,
                            "type": "1315C", 
                            "icon": "", 
                   },
                   {
                     "name": "北京铜火锅",
                     "price": 20,
                     "brand": "老北京",
                     "Count": 0,
                     "type": "1315C",
                     "icon": "",
                   },
                 ] 
              }, 
              { "name": "烧烤", 
                "type": "bbq", 
                "foods": 
                [
                  { "name": "东北烧烤", 
                    "price": 60.5, 
                    "brand": "东北人家", 
                    "Count": 0, 
                    "type": "60A", 
                    "icon": "", 
                  }
                ] 
              },
              {"name":"蔬菜",
              "type":"vegetable",
              "foods":[
                {"name": "花菜",
                "price": 3.5,
                "brand": "青蔬",
                "Count": 0,
                "type": "30A",
                "icon": "", 
                },
                {
                  "name": "青椒",
                  "price": 2.5,
                  "brand": "青蔬",
                  "Count": 0,
                  "type": "31A",
                  "icon": "",
                },
                {
                  "name": "生菜",
                  "price": 3.5,
                  "brand": "青蔬",
                  "Count": 0,
                  "type": "32A",
                  "icon": "",
                }
              ]

              }
            ], 
            toView: '0', 
            scrollTop: 100, 
            foodCounts: 0, 
            totalPrice: 0,// 总价格        
            totalCount: 0, // 总商品数        
            carArray: [],        
            minPrice: 15,//起送價格        
            payDesc: '',        
            fold: true,        
            selectFoods: [{ price: 20, count: 2 }],        
            cartShow: 'none',        
            status: 0,        
            url :"",   
      showDialog: false,     
            showPopup: false, 
            peopleNumber: "",
    GnfItems: [
      {
        id: 1,
        icon: "majiang.png",
        title: "麻将房"
      },
      {
        id: 2,
        icon: "movie.png",
        title: "私人影院"
      },
      {
        id: 3,
        icon:"boardgame.png",
        title: "桌游房"
      }
    ],
    HpgItems: [
      {
        id: 1,
        title: "X01"
      },
      {
        id: 2,
        title: "X02"
      },
      {
        id: 3,
        title: "Z01"
      }
    ],
    HpgId:'',
    GnfId: 0,
    time1: [{ time: '08:30', id: 1 }, { time: '09:00', id: 2 }, { time: '09:30', id: 3 }, { time: '10:00', id: 4 }, { time: '10:30', id: 5 }],
    time2: [{ time: '11:00', id: 6 }, { time: '11:30', id: 7 }, { time: '12:00', id: 8 }, { time: '12:30', id: 9 }, { time: '13:00', id: 10 }],
    time3: [{ time: '13:30', id: 11 }, { time: '14:00', id: 12 }, { time: '14:30', id: 13 }, { time: '15:00', id: 14 }, { time: '15:30', id: 15 }],
    time4: [{ time: '16:00', id: 16 }, { time: '16:30', id: 17 }, { time: '17:00', id: 18 }, { time: '17:30', id: 19 }, { time: '18:00', id: 20 }],
    time5: [{ time: '18:30', id: 21 }, { time: '19:00', id: 22 }, { time: '20:30', id: 23 }, { time: '21:00', id: 24 }, { time: '21:30', id: 25 }],
    isgnfintime: true,
    isgnfouttime: true,
    /**以下是功能房预定需要的数据 */
    gnfintime:{time:'8:30',id:1},
    gnfouttime: { time: '10:30', id:5},
    HpgId: 'X01',
    GnfId: 1,
    clientHeight:0,
    /**场馆选择 */
    selectPerson: true,
    firstPerson: '小和山一号馆',
    selectArea: false,

    selectPerson2: true,
    firstPerson2: '麻将房',
    selectArea2: false,

    roomPrice:0
  },

  isExistInArr: function (_array, _element) {//判断某个元素是否在数组中
    if (!_array || !_element) return false;
    if (!_array.length) {
      return (_array == _element);
    }
    for (var i = 0; i < _array.length; i++) {
      if (_element == _array[i]) return true;
    }
    return false;
  },
  distinct: function (_array) {//除去数组重复的部分
    if (!_array || !_array.length) return _array;
    var newArray = new Array();
    for (var i = 0; i < _array.length; i++) {
      var oEl = _array[i];
      if (!oEl || this.isExistInArr(newArray, oEl)) continue;
      newArray[newArray.length] = oEl;
    }
    return newArray;
  },
  onLoad: function (options) {
    var that = this;
    // 页面初始化 options为页面跳转所带来的参数
    var _this = this;
    // 页面初始化 options为页面跳转所带来的参数
    wx.getSystemInfo({
      success: function (res) {
        _this.setData({ 
          systemInfo: res 
        });
      }
    })
    
    var checkInDate = app.globalData.checkInDate ? app.globalData.checkInDate : Moment(new Date()).format('YYYY-MM-DD');
    var checkOutDate = app.globalData.checkOutDate ? app.globalData.checkOutDate : Moment(new Date()).add(0, 'day').format('YYYY-MM-DD');
    //console.log(checkInDate.toString())
    //for (var i = 0; i < app.globalData.banDate.length;i++){
    //console.log(app.globalData.banDate.length)
    //}
  },
 

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },



  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    /*
    let getDate = wx.getStorageSync("ROOM_SOURCE_DATE");
    this.setData({
      checkInDate: getDate.checkInDate,
      checkOutDate: getDate.checkOutDate
    });
    */
    this.setData({
      checkInDate: app.globalData.checkInDate,
      checkOutDate: app.globalData.checkOutDate
    });
    var checkInDate = this.data.checkInDate;
    app.globalData.checkInDate = checkInDate;

    var checkOutDate = this.data.checkOutDate;
    app.globalData.checkOutDate = checkOutDate;

    var peopleNumber = this.data.peopleNumber;
    app.globalData.peopleNumber = peopleNumber;


    this.setData({
      checkSession: app.globalData.checkSession
    })
    //console.log("入住的时间段：" + app.globalData.checkSession.checkInSession);
    //console.log("离店的时间段：" + app.globalData.checkSession.checkOutSession);
    
    //console.log("globalDate checkInDate" + app.globalData.checkInDate);
    //console.log("globalDate checkOutDate" + app.globalData.checkOutDate);

    wx.getSystemInfo({
      success: function (res) {
        console.log(res.windowHeight)
        that.setData({
          clientHeight: res.windowHeight-37.5
        });
      }
    });

    var gnfintime = parseInt(that.data.gnfintime.id);
    var gnfouttime = parseInt(that.data.gnfouttime.id);
    if (gnfouttime - gnfintime >= 4){
      var tempprice = 0;
      var price = [25,60,40];
      for (var i = gnfintime; i < gnfouttime;i++){
        tempprice += price[that.data.GnfId-1]
      }
  
      that.setData({
        roomPrice:tempprice
      })
    }
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  swichNav: function (e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current,
      })
    }
  },
  selectMenu: function (e) {
    var index = e.currentTarget.dataset.itemIndex;
    this.setData({
      toView: 'order' + index.toString()
    })
    console.log(this.data.toView);
  },
  //移除商品
  decreaseCart: function (e) {
    var index = e.currentTarget.dataset.itemIndex;
    var parentIndex = e.currentTarget.dataset.parentindex;
    this.data.goods[parentIndex].foods[index].Count--
    var name = this.data.goods[parentIndex].foods[index].name;
    var num = this.data.goods[parentIndex].foods[index].Count;
    var mark = 'a' + index + 'b' + parentIndex
    var price = this.data.goods[parentIndex].foods[index].price;
    var obj = { price: price, num: num, mark: mark, name: name, index: index, parentIndex: parentIndex };
    var carArray1 = this.data.carArray.filter(item => item.mark != mark);
    carArray1.push(obj);
    console.log(carArray1);
    for (var m = 0; m < carArray1.length; m++) {
      if (carArray1[m].num == 0) {
        carArray1.splice(m, 1);  // splice(a,b); a需要删除的位置,b删除几个
      }
    }
    this.setData({
      carArray: carArray1,
      goods: this.data.goods
    })
    this.calTotalPrice()
    this.setData({
      payDesc: this.payDesc(),
    })
    //关闭弹起
    var count1 = 0
    for (let i = 0; i < carArray1.length; i++) {
      if (carArray1[i].num == 0) {
        count1++;
      }
    }
    //console.log(count1)
    if (count1 == carArray1.length) {
      if (num == 0) {
        this.setData({
          cartShow: 'none'
        })
      }
    }
  },
  decreaseShopCart: function (e) {
    console.log('1');
    this.decreaseCart(e);
  },
  //添加到购物车
  addCart(e) {
    var index = e.currentTarget.dataset.itemIndex;
    var parentIndex = e.currentTarget.dataset.parentindex;
    this.data.goods[parentIndex].foods[index].Count++;
    var mark = 'a' + index + 'b' + parentIndex
    var price = this.data.goods[parentIndex].foods[index].price;
    var num = this.data.goods[parentIndex].foods[index].Count;
    var name = this.data.goods[parentIndex].foods[index].name;
    var obj = { price: price, num: num, mark: mark, name: name, index: index, parentIndex: parentIndex };
    var carArray1 = this.data.carArray.filter(item => item.mark != mark)
    carArray1.push(obj)
    //console.log(carArray1);
    this.setData({
      carArray: carArray1,
      goods: this.data.goods
    })
    this.calTotalPrice();
    this.setData({
      payDesc: this.payDesc()
    })
  },
  addShopCart: function (e) {
    this.addCart(e);
  },
  //计算总价
  calTotalPrice: function () {
    var carArray = this.data.carArray;
    var totalPrice = 0;
    var totalCount = 0;
    for (var i = 0; i < carArray.length; i++) {
      totalPrice += carArray[i].price * carArray[i].num;
      totalCount += carArray[i].num
    }
    this.setData({
      totalPrice: totalPrice,
      totalCount: totalCount,
      //payDesc: this.payDesc()
    });
  },
  //差几元起送
  payDesc() {
    if (this.data.totalPrice === 0) {
      return '￥'+this.data.minPrice+'元起订';
    } else if (this.data.totalPrice < this.data.minPrice) {
      let diff = this.data.minPrice - this.data.totalPrice;
      return '还差' + diff + '元起订';
    } else {
      return '选择加入场次';
    }
  },

  //购物车
  toggleList: function () {
    if (!this.data.totalCount) {
      return;
    }
    this.setData({
      fold: !this.data.fold,
    })
    var fold = this.data.fold
    //console.log(this.data.fold);
    this.cartShow(fold)
  },
  cartShow: function (fold) {
    console.log(fold);
    if (fold == false) {
      this.setData({
        cartShow: 'block',
      })
    } else {
      this.setData({
        cartShow: 'none',
      })
    }
    console.log(this.data.cartShow);
  },
  /**
  * 预览图片
  */
  togglePopup: function (event) {
    var image_path = event.currentTarget.dataset.id;
    this.setData({
      url: image_path,
      showPopup: !this.data.showPopup
    });
  },

  tabChange: function (e) {
    var showtype = e.target.dataset.type;
    this.setData({
      status: showtype,
    });
  },


//提交食物
  pay:function(){
    var that = this;
    if (that.data.totalPrice < that.data.minPrice){
      return;
    }
    if(app.globalData.isSubmit){
      wx.request({
        url: 'http://118.24.48.89/foodsubmit.php',//写自己的服务器
        header: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        method: "POST",
        data: {
          username: app.globalData.name,
          phonenum: app.globalData.phone,
        },
        success: function (e) {
          var session = ['凌晨场', '白天场', '夜晚场']
          var temp = e.data;
          for (var i = 0; i < temp.length; i++) {
            if (temp[i].hallNo == "X01") {
              temp[i].hallName = "小和山一号馆"
            }
            if (temp[i].hallNo == "X02") {
              temp[i].hallName = "小和山二号馆"
            }
            if (temp[i].hallNo == "Z01") {
              temp[i].hallName = "紫金港一号馆"
            }


            if (temp[i].InDate == temp[i].OutDate) {
              if (temp[i].InSession == temp[i].OutSession) {
                temp[i].bookTime = temp[i].InDate + temp[i].InSession
              }
              else {
                temp[i].bookTime = temp[i].InDate
                for (var j = session.indexOf(temp[i].InSession); j < session.indexOf(temp[i].OutSession) + 1; j++) {
                  temp[i].bookTime += session[j]
                }
              }
            }
            else {
              temp[i].bookTime = temp[i].InDate + temp[i].InSession + "->" + temp[i].OutDate + temp[i].OutSession;

            }

          }
          that.setData({
            tempFoodBhNo: temp
          });

          that.setData({
            showDialog: !that.data.showDialog
          });

        },
        fail: function () {
          console.log("fail")
        }

      })
    }
    else{
      that.showModel2();
    }
  
  },


  /**   * 弹窗   */  
  showDialogBtn: function () 
  { 
    this.setData({ showModal: true 
    }) 
  },  

  /**   * 弹出框蒙层截断touchmove事件   */ 
  preventTouchMove: function () 
  { 

  },  
  
  /**   * 隐藏模态对话框   */  
  hideModal: function () 
  {
     this.setData({ showModal: false 
     }); 
  },  
  
  /**   * 对话框取消按钮点击事件   */  
  
  onCancel: function () 
  { 
    this.hideModal(); 
  },  
  
  /**   * 对话框确认按钮点击事件   */  
  onConfirm: function () 
  { 
    wx.showToast({ 
      title: '提交成功', 
      icon: 'success', 
      duration: 2000 
    })    
    this.hideModal(); 
  },

  onSearch:function()
  {
    if (!app.globalData.isSubmit){
      this.showModel2();
      return;
      wx.navigateTo({
        url: '/pages/person/person'
      });
    }
    wx.navigateTo({
      url: '/pages/result/result',
    })
  },

  selectProductType: function (e) {
    var t = this, a = e.detail && e.detail.currentProductType;
    null != a && (n.setReservationType(a), t.setData({
      currentProductType: a,
      timeData: t.data.availableTimes[a]
    }), o.shareUser.orderInfoData = {
      selectedTime: !1
    }), App.zhuge.track("首页：" + this.data.productTypes[e.detail.selectedIndex].name + "tab");
  },
  selectTime: function () {
    wx.navigateTo({
      url: '/pages/calendar/calendar'
    });
  },
  selectNearSchool: function () {
    wx.navigateTo({
      url: '/pages/location/location'
    });
  },
  actionRelocate: function () {
    this.lookRoomsWithMap(), App.zhuge.track("首页：定位按钮");
  },


  showModel3: function () {
    wx.showModal({
      title: '预定成功！！',
      content: '请保持手机畅通，我们的工作人员将会联系你',
      showCancel: true,
      confirmText: '确认',
      confirmColor: '#FF0000',
      cancelText: '取消',
      cancelColor: '#999999',
      success: function (res) {
        if (res.confirm) {
          //console.log('用户点击确定');
          setTimeout(function () {//跳转
            wx.switchTab({
              url: '/pages/bill/bill',
            })
          }, 80)
        } else {
          //console.log('用户点击取消');
        }
      },
      fail: function () {
        //console.log('接口调用失败');
      },
      complete: function () {
        //console.log('接口调用结束')
      }
    })
  },
 

  showModel2: function () {
    wx.showModal({
      title: '警告⚠️',
      content: '你还未登录，请登录后完善个人信息',
      showCancel: true,
      confirmText: '确认',
      confirmColor: '#FF0000',
      cancelText: '取消',
      cancelColor: '#999999',
      success: function (res) {
        if (res.confirm) {
          //console.log('用户点击确定');
          setTimeout(function () {//跳转
            wx.switchTab({
              url: '/pages/person/person',
            })
          }, 80)
        } else {
          //console.log('用户点击取消');
        }
      },
      fail: function () {
        //console.log('接口调用失败');
      },
      complete: function () {
        //console.log('接口调用结束')
      }
    })
  },
  userNameInput: function (e) {
    this.setData({
      peopleNumber: e.detail.value
    })
  },
  toHongpa: function(e){
    if (app.globalData.isSubmit) {
      this.showModel2();//显示弹窗
      return;
    }
    app.globalData.hallNo = e.target.id;
    console.log(app.globalData.hallNo);
    
    wx.navigateTo({
      url: '../result/result'
    }) 
  },

  switchTabGnf: function (e) {
    let id = e.currentTarget.dataset.id,
      index = parseInt(e.currentTarget.dataset.index)
    this.curIndex = parseInt(e.currentTarget.dataset.index)
    var that = this
    this.setData({
      GnfId: id,
    })
    console.log(that.data.GnfId)
    this.setData({
      firstPerson2: e.target.dataset.me,
      selectPerson2: true,
      selectArea2: false,
    })

    var gnfintime = parseInt(that.data.gnfintime.id);
    var gnfouttime = parseInt(that.data.gnfouttime.id);
    if (gnfouttime - gnfintime >= 4) {
      var tempprice = 0;
      var price = [25, 60, 40];
      for (var i = gnfintime; i < gnfouttime; i++) {
        tempprice += price[that.data.GnfId - 1]
      }
      that.setData({
        roomPrice: tempprice
      })

      that.getBanRoom();
    }

  },

  switchTabHpg: function (e) {
    if (app.globalData.isSubmit) {
      this.showModel2();//显示弹窗
      return;
    }
    let id = e.currentTarget.dataset.id,
      index = parseInt(e.currentTarget.dataset.index)
    this.curIndex = parseInt(e.currentTarget.dataset.index)
    var that = this
    this.setData({
      HpgId: id,
    })
    console.log(that.data.HpgId)
    this.setData({
      firstPerson: e.target.dataset.me,
      selectPerson: true,
      selectArea: false,
    })

    that.getBanRoom();

  },

 onPress: function(e){
   var that = this;
   let id = e.currentTarget.dataset.id,
     time = e.currentTarget.dataset.time;
   var temp1 = {};
   temp1.time = time;
   temp1.id = id;
   var temp2 = {};
   temp2.time = '';
   temp2.id = '';
   if(that.data.isgnfintime == false && that.data.isgnfouttime==false){
     that.setData({
       isgnfintime:true,
       gnfintime:temp1,
       gnfouttime:temp2
     })
     that.setData({
       roomPrice: 0
     })
     return
   }
   if (that.data.isgnfintime == true && that.data.isgnfouttime == false) {
     if (id - this.data.gnfintime.id >= 4){
       that.setData({
         isgnfouttime: true,
         gnfouttime: temp1
       })
       /**计算价格 */
       var tempprice = 0;
       var price = [25, 60, 40];
       for (var i = that.data.gnfintime.id; i < that.data.gnfouttime.id; i++) {
         tempprice += price[that.data.GnfId - 1]
       }
       that.setData({
         roomPrice: tempprice
       })
       console.log(tempprice)
       console.log(that.data.gnfintime.time)
       console.log(that.data.gnfouttime.time)
       return
     }
     else if (id - this.data.gnfintime.id < 4 && id - this.data.gnfintime.id>=0){
       wx.showToast({
         title: '至少预定2小时',
         icon: 'fail',
         image:'../../images/err.png',
         duration: 1000
       })
       
       return
     }
     else{
       that.setData({
         isgnfouttime: false,
         gnfintime: temp1
       })
       that.setData({
         roomPrice: 0
       })
       return
     }

     
   }
   if (that.data.isgnfintime == true && that.data.isgnfouttime == true) {
     that.setData({
       isgnfintime: true,
       isgnfouttime: false,
       gnfintime: temp1,
       gnfouttime:temp2,
     })
     that.setData({
       roomPrice: 0
     })
     return
   }
},
bookRoom:function(e){
  var that = this;
  if(that.data.isgnfintime && that.data.isgnfouttime){
    //监听按钮
    var that = this;
    var hallNo1, roomNo1, cusName1, cusTel1, InDate1, InTime1, OutTime1;
    wx.request({
      url: 'http://118.24.48.89/newOrderRoom.php',//写自己的服务器
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      data: {
        hallNo1: that.data.HpgId,
        roomNo1:that.data.GnfId,
        cusName1: app.globalData.name,
        cusTel1: app.globalData.phone,
        InTime1: that.data.gnfintime.time,
        OutTime1: that.data.gnfouttime.time,
        price1: that.data.roomPrice,
      },
      success: function (e) {
        //console.log("success new Order room")
        //console.log(e.data);
        this.showModel3();
      },
      fail: function () {
        console.log("fail")
      }
    })
  }else{
    wx.showToast({
      title: '请选择时间',
      icon: 'fail',
      image: '../../images/err.png',
      duration: 1000
    })
    return
  }

  },

  clickPerson: function () {
    var selectPerson = this.data.selectPerson;
    if (selectPerson == true) {
      this.setData({
        selectArea: true,
        selectPerson: false,
      })
    } else {
      this.setData({
        selectArea: false,
        selectPerson: true,
      })
    }
  },
  clickPerson2: function () {
    var selectPerson2 = this.data.selectPerson2;
    if (selectPerson2 == true) {
      this.setData({
        selectArea2: true,
        selectPerson2: false,
      })
    } else {
      this.setData({
        selectArea2: false,
        selectPerson2: true,
      })
    }
  },
  //点击切换
  mySelect: function (e) {
    this.setData({
      firstPerson: e.target.dataset.me,
      selectPerson: true,
      selectArea: false,
    })
  }, 





  click: function (e) {
    var id = e.currentTarget.dataset.id
    var that = this
    that.setData({
      id: id
    })
  },
  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value)
    var that = this
    that.setData({
      realTempFoodBhNo: e.detail.value
    })
    console.log(this.data.realTempFoodBhNo)
  },
  toggleDialog() {
    this.setData({
      showDialog: !this.data.showDialog
    });
  },
  freeBack: function () {
    var that = this
    if (this.data.realTempFoodBhNo == '') {
      wx.showModal({
        title: '提示',
        content: '你没有选择任何内容',
      })
    }
    that.setData({
      showDialog: !this.data.showDialog
    })
    console.log(that.data.realTempFoodBhNo);
    

    var that = this;
    var str = ""
    for (var i = 0; i < that.data.carArray.length; i++) {
      var x = {};
      x.price = that.data.carArray[i].price
      x.num = that.data.carArray[i].num
      x.name = that.data.carArray[i].name
      x.totalprice = that.data.carArray[i].price * that.data.carArray[i].num
      str += JSON.stringify(x);
    }
    console.log(str);
    wx.request({
      url: 'http://118.24.48.89/food.php',//写自己的服务器
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: "POST",
      data: {
        username: app.globalData.name,
        phonenum: app.globalData.phone,
        bhNo:that.data.realTempFoodBhNo,
        foodName:str,
        foodPrice: that.data.totalPrice
      },
      success: function (e) {
      },
      fail:function(){

      }
    })
  },
  freetoBack: function () {
    var that = this
    wx.showModal({
      title: '提示',
      content: '你没有选择任何内容',
    })
    that.setData({
      showDialog: !this.data.showDialog,
      value: 'show',
      checked: false,
    })
  },
})