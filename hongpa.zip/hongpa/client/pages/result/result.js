// pages/result/result.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host:"https://www.paintorange.com/",
    hall:app.globalData.hall,
    hallName:'',
    location:"",
    phone:'',
    qrcode:'',
    tempid:0,
    GnfItems:[],

    GnfItems1: [
      {
        id: 1,
        icon: "bbq.png",
        title: "烧烤"
      },
      {
        id: 2,
        icon: "zhuoyou.png",
        title: "桌游室"
      },
      {
        id: 3,
        icon: "yinyin.png",
        title: "影音室"
      },
      {
        id: 4,
        icon: "majiangg.png",
        title: "麻将室"
      },
      {
        id: 5,
        icon: "kitchen.png",
        title: "厨房"
      },
    ],
    GnfItems2: [
      {
        id: 1,
        icon: "KTV.png",
        title: "KTV"
      },
      {
        id: 2,
        icon: "zhuoyou.png",
        title: "桌游室"
      },
      {
        id: 3,
        icon: "yinyin.png",
        title: "影音室"
      },
      {
        id: 4,
        icon: "majiangg.png",
        title: "麻将室"
      },
      {
        id: 5,
        icon: "kitchen.png",
        title: "厨房"
      },
    ],
    GnfItems3: [
      {
        id: 1,
        icon: "KTV.png",
        title: "KTV"
      },
      {
        id: 2,
        icon: "zhuoyou.png",
        title: "桌游室"
      },
      {
        id: 3,
        icon: "yinyin.png",
        title: "影音室"
      },
      {
        id: 4,
        icon: "majiangg.png",
        title: "麻将室"
      },
      {
        id: 5,
        icon: "kitchen.png",
        title: "厨房"
      },
    ],
    sheshi:[
      {
        id : 1,
        name: "餐具",
        goods: [["碗40/只","筷子40/双","盘子30/只"]]
      },
      {
        id: 2,
        name: "厨具",
        goods: [["鸳鸯锅X2", "电磁炉X2", "炒锅X2"], ["烤箱", "电饭煲", "电热水壶"],["平底锅"]]
      },
      {
        id: 3,
        name: "娱乐",
        goods: [["坚果投影仪", "麻将机"], ["X-BOX", "骰盅"]]
      },
      {
        id: 4,
        name: "桌游",
        goods: [["德州扑克", "筹码", "狼人杀"], ["德国心脏病", "三国杀", "UNO"],["达芬奇密码", "卡坦岛", "阿瓦隆"]]
      }
    ]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var tempName = ''
    var tempLocation = ''
    var tempPhone = ''
    var tempqrcode = ''
    var tempid = 0
    var GnfItems = []
    for(var i=0;i<app.globalData.hall.length;i++){
      if(app.globalData.hall[i].No == app.globalData.hallNo ){
        tempLocation = app.globalData.hall[i].location
        tempName = app.globalData.hall[i].name
        tempPhone = app.globalData.hall[i].phone
        tempqrcode = app.globalData.hall[i].qrcode
        tempid = app.globalData.hall[i].id
        GnfItems = app.globalData.hall[i].GnfItems
      }
    }
    that.setData({
      location:tempLocation,
      hallName:tempName,
      phone: tempPhone,
      qrcode: tempqrcode,
      tempid:tempid,
      GnfItems: GnfItems
    })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onSearch: function () {
    wx.navigateTo({
      url: '../../pages/chooseTime/chooseTime',
    })
  },
  imgYu: function (event) {
   var that =this;
   var qrcode = that.data.qrcode;
    wx.previewImage({
      urls: ["https://www.paintorange.com/images/"+qrcode+".jpg"]// 需要预览的图片http链接列表
    })
  }
})