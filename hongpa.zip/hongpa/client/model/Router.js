var o = require("/Url.js"), e = {
    autoVerify: function(e) {
        var r = e, n = r.url;
        if (0 == n.includes("?") && 1 == n.endsWith("&")) console.log("-------------跳转URL不合法--------------"), 
        console.log("原URL为:" + n), n = n.substr(0, n.length - 1), console.log("已纠正为:" + n), 
        console.log("--------------------------------------"); else if (n.includes("?")) {
            var t = n.indexOf("?");
            if (t != n.lastIndexOf("?")) {
                if (console.log("-------------跳转URL不合法--------------"), 0 == o.isOnline) throw console.log("URL为: " + n), 
                "!!!!!!!!!!跳转URL不合法!!!!!!!!!!";
                console.log("原URL为:" + n), n = n.substr(0, t), console.log("已纠正为:" + n), console.log("--------------------------------------");
            }
            n.endsWith("?") && (n = n.substr(0, n.length - 1));
        }
        if (r.data) {
            var i = r.data, s = encodeURIComponent(JSON.stringify(i));
            n = n + (n.endsWith("&") ? "" : "?") + "router=" + s;
        }
        return r.url = n, r;
    },
    prase: function(o) {
        if (o.router) {
            var e = decodeURIComponent(o.router);
            return JSON.parse(e);
        }
        return console.error("该页面并未传入Router数据"), {};
    },
    push: function(o) {
        var e = this.autoVerify(o);
        wx.navigateTo(e);
    },
    pop: function(o) {
        wx.navigateBack(o);
    },
    redirectTo: function(o) {
        var e = this.autoVerify(o);
        wx.redirectTo(e);
    },
    switchTab: function(o) {
        var e = this.autoVerify(o);
        wx.switchTab(e);
    },
    relaunch: function(o) {
        var e = this.autoVerify(o);
        wx.reLaunch(e);
    }
};

module.exports = e;