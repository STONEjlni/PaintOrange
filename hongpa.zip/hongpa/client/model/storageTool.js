var e = require("User.js"), t = require("./Constant.js");

module.exports.loadUserData = function(e) {
    wx.getStorage({
        key: t.USER_STORAGE_KEY,
        success: function(t) {
            e.success && "function" == typeof e.success && e.success(t.data);
        },
        fail: function() {
            e.fail && "function" == typeof e.fail && e.fail();
        },
        complete: function() {
            e.complete && "function" == typeof e.complete && e.complete();
        }
    });
}, module.exports.asyncStorageUserData = function() {
    var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    wx.setStorage({
        key: t.USER_STORAGE_KEY,
        data: e.shareUser,
        success: s.success,
        fail: s.fail,
        complete: s.complete
    });
};