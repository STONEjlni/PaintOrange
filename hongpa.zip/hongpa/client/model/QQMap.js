function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(t, n, o) {
        return n && e(t.prototype, n), o && e(t, o), t;
    };
}(), o = e(require("../framework/qqmap-wx-jssdk.min")), r = e(require("./Constant")), a = e(require("./User")), s = void 0, i = function() {
    function e() {
        return t(this, e), void 0 === s && (this.mapWX = new o.default({
            key: r.default.QQ_MAP_SDK_KEY
        }), s = this), s;
    }
    return n(e, [ {
        key: "getLocation",
        value: function() {
            var e = this, t = {};
            return new Promise(function(n, o) {
                wx.getLocation({
                    type: "gcj02",
                    success: function(r) {
                        t.latitude = r.latitude, t.longitude = r.longitude, e.mapWX.reverseGeocoder({
                            location: {
                                latitude: r.latitude,
                                longitude: r.longitude
                            },
                            success: function(e) {
                                var o = e.result || {};
                                console.log("位置信息", o), a.default.shareUser.userRefusedLocation = !1, o.formatted_addresses && o.formatted_addresses.recommend && (t.address = o.formatted_addresses.recommend), 
                                o.address_component && (t.city = o.address_component.city, t.district = o.address_component.district, 
                                t.nation = o.address_component.nation, t.province = o.address_component.province, 
                                t.street = o.address_component.street, t.street_number = o.address_component.street_number), 
                                a.default.shareUser.locationInfo = t, n(t);
                            },
                            fail: function(e) {
                                o(e);
                            }
                        });
                    },
                    fail: function(e) {
                        o(e);
                    }
                });
            });
        }
    }, {
        key: "searchLocation",
        value: function(e) {
            var t = e.keyword, n = void 0 === t ? "" : t, o = (e.location, e.address_format, 
            e.page_size, e.page_index, this);
            return new Promise(function(e, t) {
                o.mapWX.search({
                    keyword: n,
                    success: function(t) {
                        e(t);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        }
    }, {
        key: "keywordSearch",
        value: function() {
            var e = "https://apis.map.qq.com/ws/place/v1/suggestion/?region=" + (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "") + "&keyword=" + (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "") + "&key=" + r.default.QQ_MAP_SDK_KEY;
            return new Promise(function(t, n) {
                wx.request({
                    url: e,
                    method: "GET",
                    success: function(e) {
                        var o = e.data && e.data.data;
                        o ? t(o) : n(e);
                    },
                    fail: function(e) {
                        n(e);
                    }
                });
            });
        }
    }, {
        key: "addressResolution",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = "https://apis.map.qq.com/ws/geocoder/v1/?address=" + e + "&region=" + e + "&key=" + r.default.QQ_MAP_SDK_KEY;
            return new Promise(function(e, n) {
                wx.request({
                    url: t,
                    method: "GET",
                    success: function(t) {
                        var o = t.data && t.data.result;
                        o ? e(o) : n(t);
                    },
                    fail: function(e) {
                        n(e);
                    }
                });
            });
        }
    } ]), e;
}();

exports.default = i;