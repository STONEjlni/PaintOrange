function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(t, n, o) {
        return n && e(t.prototype, n), o && e(t, o), t;
    };
}(), n = void 0, o = function() {
    function o() {
        return e(this, o), n || (this.onObj = {}, this.oneObj = {}, n = this), n;
    }
    return t(o, [ {
        key: "on",
        value: function(e, t) {
            e && t && "string" == typeof e && "function" == typeof t ? (this.onObj[e] = this.onObj[e] || [], 
            this.onObj[e].push(t)) : console.error("incorrect parameters: the type of parameter key must be string, and the type of parameter fun must be function");
        }
    }, {
        key: "one",
        value: function(e, t) {
            e && t && "string" == typeof e && "function" == typeof t ? (this.oneObj[e] = this.oneObj[e] || [], 
            this.oneObj[e].push(t)) : console.error("incorrect parameters: the type of parameter key must be string, and the type of parameter fun must be function");
        }
    }, {
        key: "off",
        value: function(e) {
            e && "string" == typeof e ? (this.oneObj[e] = [], this.onObj[e] = []) : console.error("incorrect parameters: the type of parameter key must be string");
        }
    }, {
        key: "offAll",
        value: function() {
            this.oneObj = {}, this.onObj = {};
        }
    }, {
        key: "trigger",
        value: function(e) {
            for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), o = 1; o < t; o++) n[o - 1] = arguments[o];
            e && "string" == typeof e ? (void 0 !== this.onObj[e] && this.onObj[e].length > 0 && this.onObj[e].forEach(function(e) {
                e.apply(null, n);
            }), void 0 !== this.oneObj[e] && this.oneObj[e].length > 0 && (this.oneObj[e].forEach(function(e) {
                e.apply(null, n);
            }), this.oneObj[e] = [])) : console.error("incorrect parameters: the type of parameter key must be string");
        }
    } ]), o;
}();

exports.default = o;