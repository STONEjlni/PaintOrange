function e(e) {
    i = parseInt(e.diffTime), t();
}

function n() {
    clearTimeout(r);
}

function t() {
    if (i > 0) {
        i -= 1;
        var e = Math.floor(i / 60 / 60 / 24), u = Math.floor(i / 60 / 60 % 24), s = Math.floor(i / 60 % 60), a = Math.floor(i % 60);
        u = u < 10 ? "0" + u : u, s = s < 10 ? "0" + s : s, a = a < 10 ? "0" + a : a;
        var f = {};
        o.day && Object.assign(f, {
            day: e
        }), o.hour && Object.assign(f, {
            hour: u
        }), o.minute && Object.assign(f, {
            minute: s
        }), o.second && Object.assign(f, {
            second: a
        }), o.onUpdate && o.onUpdate(f), r = setTimeout(t, 1e3);
    } else {
        if (n(), i < 0) return;
        o.onEnd && o.onEnd();
    }
}

var o = null, i = 0, r = null;

module.exports = function(t) {
    if (o = "number" == typeof t ? {
        diffTime: t,
        day: !0,
        hour: !0,
        minute: !0,
        second: !0
    } : t, o.day = t.day || !0, o.hour = t.hour || !0, o.minute = t.minute || !0, o.second = t.second || !0, 
    "number" != typeof o.diffTime || !o.diffTime) throw new Error("the parameter diffTime must be number");
    this.endCountDown = n, this.startCountDown = e, this.startCountDown(o);
};