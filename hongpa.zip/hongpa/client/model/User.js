var e = function() {
    function e() {
        return {
            publicMethod: function() {},
            nickName: "",
            country: "",
            province: "",
            city: "",
            headimgUrl: "",
            gender: 0,
            locationInfo: {
                latitude: 39.998813,
                longitude: 116.317489
            },
            isVerified: !1,
            isStudent: !1,
            studentVerifyState: 0,
            schoolName: "",
            phoneNumber: "",
            name: "",
            identifyID: "",
            isLogin: !1,
            isVip: !1,
            user_id: "",
            open_id: "",
            searchHistory: [],
            telephone: "13021276464",
            roomInfoData: {},
            orderInfoData: {
                selectedTime: !1
            },
            tempOrderInfoData: {
                selectedTime: !1
            },
            defaultInfoData: {
                selectedTime: !1
            },
            reservationType: 1,
            houseSource: -1,
            userRefusedLocation: !0,
            availableTimes: {}
        };
    }
    var t = void 0;
    return {
        shareInstance: function() {
            return t || (t = e()), t;
        }
    };
}();

module.exports.User = e, module.exports.shareUser = e.shareInstance();