Promise.prototype.finally = Promise.prototype.finally || function(t) {
    var e = this.constructor;
    return this.then(function(r) {
        return e.resolve(t()).then(function() {
            return r;
        });
    }, function(r) {
        return e.resolve(t()).then(function() {
            throw r;
        });
    });
}, !Array.prototype.includes && Object.defineProperty(Array.prototype, "includes", {
    value: function(t, e) {
        if (null == this) throw new TypeError('"this" is null or not defined');
        var r = Object(this), n = r.length >>> 0;
        if (0 === n) return !1;
        for (var i = 0 | e, o = Math.max(i >= 0 ? i : n - Math.abs(i), 0); o < n; ) {
            if (r[o] === t) return !0;
            o++;
        }
        return !1;
    }
}), String.prototype.includes = String.prototype.includes || function(t, e) {
    return "number" != typeof e && (e = 0), !(e + t.length > this.length) && -1 !== this.indexOf(t, e);
}, Date.prototype.Format = function(t) {
    var e = {
        "y+": this.getFullYear(),
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    for (var r in e) if (new RegExp("(" + r + ")").test(t)) if ("y+" === r) t = t.replace(RegExp.$1, ("" + e[r]).substr(4 - RegExp.$1.length)); else if ("S+" === r) {
        var n = RegExp.$1.length;
        n = 1 === n ? 3 : n, t = t.replace(RegExp.$1, ("00" + e[r]).substr(("" + e[r]).length - 1, n));
    } else t = t.replace(RegExp.$1, 1 === RegExp.$1.length ? e[r] : ("00" + e[r]).substr(("" + e[r]).length));
    return t;
};