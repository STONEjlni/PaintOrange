var e = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var t = arguments[r];
        for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
}, r = function() {
    function e(e, r) {
        var t = [], a = !0, n = !1, o = void 0;
        try {
            for (var i, s = e[Symbol.iterator](); !(a = (i = s.next()).done) && (t.push(i.value), 
            !r || t.length !== r); a = !0) ;
        } catch (e) {
            n = !0, o = e;
        } finally {
            try {
                !a && s.return && s.return();
            } finally {
                if (n) throw o;
            }
        }
        return t;
    }
    return function(r, t) {
        if (Array.isArray(r)) return r;
        if (Symbol.iterator in Object(r)) return e(r, t);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), t = require("./User.js"), a = {};

a.renderFormatTime = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if ("string" != typeof e || !e.includes(" ")) return "";
    var a = e.split(" "), n = r(a, 2), o = n[0], i = n[1], s = o.split("-"), d = r(s, 3), l = (d[0], 
    d[1]), u = d[2], h = i.split(":"), v = r(h, 3), c = v[0], f = v[1];
    v[2];
    return t ? c + ":" + f : l + "月" + u + "日" + c + ":" + f;
}, a.validateDateAndTimeFormat = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    return /^[1-9]\d{3}(-|\/)(0[1-9]|1[0-2])(-|\/)(0[1-9]|[1-2][0-9]|3[0-1])\s+(20|21|22|23|[0-1]\d):[0-5]\d:[0-5]\d$/.test(e);
}, a.validateDateFormat = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    return /^[1-9]\d{3}(-|\/)(0[1-9]|1[0-2])(-|\/)(0[1-9]|[1-2][0-9]|3[0-1])$/.test(e);
}, a.validateTimeFormat = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    return /^(20|21|22|23|[0-1]\d):[0-5]\d:[0-5]\d$/.test(e);
}, a.convertDateFromString = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    return e = e.replace(/-/g, "/"), new Date(e);
}, a.splitTimeString = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "number", t = e.split(" "), a = void 0, n = void 0, o = void 0, i = void 0, s = void 0, d = void 0;
    if (2 === t.length) {
        var l = t[0].includes("-") ? "-" : "/", u = t[0].split(l);
        3 === u.length && (a = "number" === r ? parseInt(u[0]) : u[0], n = "number" === r ? parseInt(u[1]) : u[1], 
        o = "number" === r ? parseInt(u[2]) : u[2]);
        var h = t[1].split(":");
        3 === h.length && (i = "number" === r ? parseInt(h[0]) : h[0], s = "number" === r ? parseInt(h[1]) : h[1], 
        d = "number" === r ? parseInt(h[2]) : h[2]);
    }
    return null != a && null != n && null != o && null != i && null != s && null != d && {
        year: a,
        month: n,
        date: o,
        hour: i,
        minute: s,
        second: d
    } || "";
}, a.uuid = function() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
        var r = 16 * Math.random() | 0;
        return ("x" === e ? r : 3 & r | 8).toString(16);
    });
}, a.calculateDate = function(e, r, t) {
    var a = new Date(e.toString());
    switch (t) {
      case "day":
        return a.setDate(a.getDate() + parseInt(r)), a;

      case "month":
        return a.setMonth(a.getMonth() + parseInt(r)), a;
    }
}, a.calculateMinutes = function(e) {
    var r = e.split(":");
    return 60 * parseInt(r[0]) + parseInt(r[1]);
}, a.calculateInterval = function(e, r) {
    var t = a.calculateMinutes(e), n = a.calculateMinutes("24:00"), o = a.calculateMinutes("0:00");
    return (n - t) / 60 + (a.calculateMinutes(r) - o) / 60;
}, a.bracketIndexOf = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = e.indexOf("(");
    return r = null == r ? -1 : r, r = -1 === r ? e.indexOf("（") : r;
}, a.splitStringUntilLeftBracket = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
    return r > -1 ? e.substr(0, r) : e;
}, a.showNetworkErrorModel = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    wx.showModal({
        title: e,
        content: "网络状态不太好T_T\n请检查您的网络连接",
        confirmColor: "#FC627A",
        showCancel: !1
    });
}, a.showToast = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3, t = arguments[2];
    t ? (wx.showToast({
        title: e,
        icon: "none",
        mask: !0,
        duration: r
    }), setTimeout(t, r)) : wx.showToast({
        title: e,
        icon: "none",
        mask: !0,
        duration: r
    });
}, a.contactCustomService = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : t.shareUser.telephone, r = new Date().getHours();
    r >= 1 && r <= 9 ? wx.showModal({
        title: "提示",
        content: "客服盒仔在线时间为: 早上10:00-凌晨1:00",
        showCancel: !1,
        confirmColor: "#333333"
    }) : wx.makePhoneCall({
        phoneNumber: e
    });
}, a.setAvailableTimes = function() {
    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = [], n = 0; n < 3; n++) {
        var o = a.setOrderTimeFormat(e[n], n);
        r.push(o);
    }
    t.shareUser.availableTimes = r;
}, a.setOrderTimeFormat = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments[1], t = {}, a = e.startTime.split(" ")[1].split(":").slice(0, 2).join(":"), n = e.endTime.split(" ")[1].split(":").slice(0, 2).join(":");
    return t.selectedTime = !0, t.day = e.day, t.displayTime = e.display, t.startTime = e.startTime, 
    t.endTime = e.endTime, t.startHour = a, t.endHour = n, t.duration = e.duration, 
    t.reservationType = r, t;
}, a.setOrderInfoData = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
    t.shareUser.orderInfoData = t.shareUser.availableTimes[e];
}, a.addEarlyCheckInTime = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "21:00", a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "19:00", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2, o = t.shareUser.orderInfoData;
    return 0 == t.shareUser.reservationType && (t.shareUser.orderInfoData.displayTime = o.displayTime.replace(r, a), 
    t.shareUser.orderInfoData.startHour = a, t.shareUser.orderInfoData.duration += n, 
    t.shareUser.orderInfoData.startTime = o.startTime.replace(r, a), t.shareUser.orderInfoData.selectedTime = !0), 
    e({}, t.shareUser.orderInfoData);
}, a.removeEarlyCheckInTime = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "19:00", a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "21:00", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2, o = t.shareUser.orderInfoData;
    return 0 == t.shareUser.reservationType && (t.shareUser.orderInfoData.displayTime = o.displayTime.replace(r, a), 
    t.shareUser.orderInfoData.startHour = a, t.shareUser.orderInfoData.duration -= n, 
    t.shareUser.orderInfoData.startTime = o.startTime.replace(r, a), t.shareUser.orderInfoData.selectedTime = !0), 
    e({}, t.shareUser.orderInfoData);
}, a.addLaterCheckOutTime = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "11:00", a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "13:00", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2, o = t.shareUser.orderInfoData;
    if (0 == t.shareUser.reservationType) {
        var i = o.duration + n;
        t.shareUser.orderInfoData.endHour = a, t.shareUser.orderInfoData.duration = i, t.shareUser.orderInfoData.endTime = o.endTime.replace(r, a), 
        t.shareUser.orderInfoData.selectedTime = !0, t.shareUser.orderInfoData.displayTime = o.day.substr(-5).replace("-", "/") + " " + o.startHour + "-次日 " + o.endHour + " 共" + i + "小时";
    }
    return e({}, t.shareUser.orderInfoData);
}, a.removeLaterCheckOutTime = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "13:00", a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "11:00", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2, o = t.shareUser.orderInfoData;
    if (0 == t.shareUser.reservationType) {
        var i = o.duration - n;
        t.shareUser.orderInfoData.endHour = a, t.shareUser.orderInfoData.duration = i, t.shareUser.orderInfoData.endTime = o.endTime.replace(r, a), 
        t.shareUser.orderInfoData.selectedTime = !0, t.shareUser.orderInfoData.displayTime = o.day.substr(-5).replace("-", "/") + " " + o.startHour + "-次日 " + o.endHour + " 共" + i + "小时";
    }
    return e({}, t.shareUser.orderInfoData);
}, a.setReservationType = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
    return t.shareUser.reservationType = e, e;
}, a.judgeSummerVacation = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 31, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 26, t = new Date(), a = t.getMonth(), n = t.getDate(), o = !1, i = !1;
    return 6 === a ? (o = n > 15 && n < 32, i = n > 15 && n < 32) : 7 === a && (o = n > 0 && n < e, 
    i = n > 0 && n < r), {
        timeSharingModeDisabled: o,
        overnightModeDisabled: i
    };
}, a.setSummerVacationMode = function() {
    var e = a.judgeSummerVacation(32), r = e.timeSharingModeDisabled, n = void 0 !== r && r, o = e.overnightModeDisabled, i = void 0 !== o && o;
    (n || i) && (t.shareUser.reservationType = 2);
}, module.exports = a;