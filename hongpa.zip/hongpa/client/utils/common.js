function getPrice(InDate, InSession, OutDate, OutSession, hallNo, bill, callback) {
  //console.log(InDate, InSession, OutDate, OutSession)
  var price = 0;
  wx.request({
    url: 'http://118.24.48.89/price.php',//写自己的服务器
    header: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    method: "POST",
    data: {
      InDate: InDate,
      InSession: InSession,
      OutDate: OutDate,
      OutSession: OutSession,
      hallNo: hallNo
    },
    success: function (res) {
      console.log("res:" + res.data);
      return typeof callback == "function" && callback(res.data)
    },
    fail: function () {
      //console.log("fail")
      return typeof callback == "function" && callback(false)
    }

  })
}

module.exports = {
  getPrice: getPrice,
}