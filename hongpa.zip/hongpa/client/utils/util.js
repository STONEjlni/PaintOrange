var app= getApp();
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}


// 显示繁忙提示
var showBusy = text => wx.showToast({
    title: text,
    icon: 'loading',
    duration: 10000
})

// 显示成功提示
var showSuccess = text => wx.showToast({
    title: text,
    icon: 'success'
})

// 显示失败提示
var showModel = (title, content) => {
    wx.hideToast();

    wx.showModal({
        title,
        content: JSON.stringify(content),
        showCancel: false
    })
}

function getApi(url,params){
  return new Promise((res,rej) => {
    wx.request({
      url: API_URL + '/' + url + '?' + 'Sno=' + params,
      data: Object.assign({},params),
      //dataType:JSON,
      header:{'Content-Type': 'application/json' },
      success: function(res){
        console.log('返回结果: ')
        app.btn = res.data.data
      },
      fail: rej
    })
  })
}

module.exports = { 
  formatTime, 
  showBusy, 
  showSuccess, 
  showModel,
  }
